package com.app.universityblog.main.models;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import nonapi.io.github.classgraph.json.Id;
import org.springframework.data.mongodb.core.mapping.Document;

import java.util.Date;
import java.util.List;

@AllArgsConstructor
@NoArgsConstructor
@Data
@Document(collection = "polls")
public class Poll {
    @Id
    private String id;
    private String question;
    private List<Option> options;
    private int totalVotes;
    private List <String> votedUserIds;
    private Date expiresAt;
//    private String visibility;


    private List<String> option;
    private String OptionSelected;

    // Constructors, getters, and setters




}
