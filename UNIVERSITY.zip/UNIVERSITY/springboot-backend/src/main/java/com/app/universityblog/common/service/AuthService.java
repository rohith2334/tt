package com.app.universityblog.common.service;

import com.app.universityblog.common.payload.request.LoginRequest;
import com.app.universityblog.common.payload.request.SignupRequest;
import org.springframework.http.ResponseEntity;

public interface AuthService {

    ResponseEntity<?> registerUser(SignupRequest signUpRequest) ;

    ResponseEntity<?> authenticateUser( LoginRequest loginRequest);
}
