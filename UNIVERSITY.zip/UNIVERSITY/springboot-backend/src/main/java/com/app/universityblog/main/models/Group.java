package com.app.universityblog.main.models;


import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import nonapi.io.github.classgraph.json.Id;
import org.springframework.data.mongodb.core.index.TextIndexed;
import org.springframework.data.mongodb.core.mapping.Document;

import java.util.Date;
import java.util.List;

@AllArgsConstructor
@NoArgsConstructor
@Data
@Document(collection = "groups")
public class Group {
    @Id
    private String id;
    @TextIndexed
    private String name;
    private String createdBy;
    private String profileImage;
    private String coverImage;
    private boolean verified;
    private List<String> members;
//    private String admin;
//    private Object setting;
    @TextIndexed
    private String description;
//    private List<String> tags;
    private String visibility;
    private Date createdAt;
    private Date updatedAt;
    private List<String> pendingRequests;
    private List<String> bannedUsers;
    private boolean featured;
}
