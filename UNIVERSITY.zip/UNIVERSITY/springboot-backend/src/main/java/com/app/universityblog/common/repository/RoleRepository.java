package com.app.universityblog.common.repository;

import com.app.universityblog.common.models.ERole;
import com.app.universityblog.common.models.Role;
import org.springframework.data.mongodb.repository.MongoRepository;

import java.util.Optional;

public interface RoleRepository extends MongoRepository<Role, String> {
  Optional<Role> findByName(ERole name);
}
