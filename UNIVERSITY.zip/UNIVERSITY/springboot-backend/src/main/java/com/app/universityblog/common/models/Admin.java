package com.app.universityblog.common.models;


import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.springframework.data.annotation.Id;

@AllArgsConstructor
@NoArgsConstructor
@Data
@Builder
public class Admin {
    @Id
    private String id;
    private String userId;
    private String username;
    private String email;
    private String password;
    private String profileImage;
    private String createdAt;
    private String updatedAt;
}
