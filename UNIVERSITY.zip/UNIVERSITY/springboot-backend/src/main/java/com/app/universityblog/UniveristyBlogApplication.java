package com.app.universityblog;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class UniveristyBlogApplication {

	public static void main(String[] args) {
		SpringApplication.run(UniveristyBlogApplication.class, args);
	}

}
