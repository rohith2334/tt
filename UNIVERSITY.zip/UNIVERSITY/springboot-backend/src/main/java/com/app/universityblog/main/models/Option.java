package com.app.universityblog.main.models;


import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.List;

@AllArgsConstructor
@NoArgsConstructor
@Data
public class Option {
    private String id;
    private List<String> voters;
    private String optionText;
    private int votes;
}
