package com.app.universityblog.main.service;

import com.app.universityblog.common.utils.CommonUtils;
import com.app.universityblog.main.models.Group;
import com.app.universityblog.main.models.Invitation;
import com.app.universityblog.main.models.Profile;
import com.app.universityblog.main.payload.request.GroupRequest;
import com.app.universityblog.main.payload.response.GroupResponse;
import com.app.universityblog.main.repository.GroupRepository;
import com.app.universityblog.main.repository.ProfileRepository;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

@Service
public class GroupServiceImpl implements GroupService {

    private GroupRepository groupRepository;
    private ProfileRepository profileRepository;

    private final CommonUtils commonUtils;
    private final NotificationService notificationService;

    public GroupServiceImpl(GroupRepository groupRepository, ProfileRepository profileRepository, CommonUtils commonUtils, NotificationService notificationService) {
        this.groupRepository = groupRepository;
        this.profileRepository = profileRepository;
        this.commonUtils = commonUtils;
        this.notificationService = notificationService;
    }


    @Override
    public ResponseEntity<?> createGroup(GroupRequest group) {
        try {
            Group _group = new Group();
            _group.setName(group.getName());
            _group.setDescription(group.getDescription());
            _group.setProfileImage(group.getProfileImage());
            _group.setCoverImage(group.getCoverImage());
            _group.setCreatedBy(commonUtils.getUserId().toString());
            _group.setCreatedAt(commonUtils.getCurrentDate());
            _group.setUpdatedAt(commonUtils.getCurrentDate());
            _group.setPendingRequests(List.of());
            _group.setBannedUsers(List.of());
            _group.setMembers(List.of(commonUtils.getUserId().toString()));
            Group _groupResponse = groupRepository.save(_group);
            Profile profile=profileRepository.findByUserId(commonUtils.getUserId().toString());
            profile.getGroups().add(_groupResponse.getId());
            profileRepository.save(profile);

            return ResponseEntity.ok().build();
        } catch (Exception e) {
            throw new RuntimeException("Group not created");
        }
    }

    @Override
    public ResponseEntity<GroupResponse> getGroupById(String groupId) {
        try {
            Group group = groupRepository.findById(groupId).get();
            return ResponseEntity.ok(constructGroupResponse(group));
        } catch (Exception e) {
            throw new RuntimeException("Group not found");
        }
    }

    @Override
    public ResponseEntity<List<GroupResponse>> getGroups() {
        try {
            List<Group> groups = groupRepository.findAll();

            List<GroupResponse> groupResponses = new ArrayList<>();
            for (Group group : groups) {
                GroupResponse constructGroupResponse = constructGroupResponse(group);
                groupResponses.add(constructGroupResponse);
            }
            return ResponseEntity.ok(groupResponses);
        } catch (Exception e) {
            throw new RuntimeException("Groups not found");
        }
    }

    @Override
    public ResponseEntity<?> deleteGroup(String groupId) {
        try {
            Group group = groupRepository.findById(groupId).get();
            if (!checkLoggedInUser(group.getCreatedBy())) {
                throw new RuntimeException("You are not authorized to perform this action");
            }
            group.getMembers().forEach(member -> {
                Profile profile = profileRepository.findByUserId(member);
                profile.getGroups().remove(groupId);
                profileRepository.save(profile);
            });
            groupRepository.deleteById(groupId);
            return ResponseEntity.ok().build();
        } catch (Exception e) {
            System.out.println(e.getMessage());
        }
        return ResponseEntity.ok().build();
    }

   @Override
public ResponseEntity<GroupResponse> updateGroup(String groupId, Group group) {
    return groupRepository.findById(groupId)
            .map(_group -> {
                Optional.ofNullable(group.getName()).ifPresent(_group::setName);
                Optional.ofNullable(group.getCreatedBy()).ifPresent(_group::setCreatedBy);
                Optional.ofNullable(group.getMembers()).ifPresent(_group::setMembers);
                Optional.ofNullable(group.getDescription()).ifPresent(_group::setDescription);
                Optional.ofNullable(group.getVisibility()).ifPresent(_group::setVisibility);
                Optional.ofNullable(group.getCreatedAt()).ifPresent(_group::setCreatedAt);
                Optional.ofNullable(group.getUpdatedAt()).ifPresent(_group::setUpdatedAt);
                Optional.ofNullable(group.getPendingRequests()).ifPresent(_group::setPendingRequests);
                Optional.ofNullable(group.getBannedUsers()).ifPresent(_group::setBannedUsers);
                Optional.ofNullable(group.isFeatured()).ifPresent(_group::setFeatured);
                groupRepository.save(_group);
                return ResponseEntity.ok(constructGroupResponse(_group));
            })
            .orElseThrow(() -> new RuntimeException("Group not found"));
}

    @Override
    public ResponseEntity<?> updateRequestStatus(String groupId, String userId, String status) {
        try {
            Group group = groupRepository.findById(groupId).get();
            if(!checkLoggedInUser(group.getCreatedBy())){
                throw new RuntimeException("You are not authorized to perform this action");
            }
            if (status.equals("accept")) {
                group.getMembers().add(userId);
                Profile profile= profileRepository.findByUserId(userId);
                profile.getGroups().add(groupId);
                notificationService.sendNotification(userId, "Your request to join group "+ group.getName() +" has been accepted");
                profileRepository.save(profile);
            }else if(status.equals("ban")){
            if(group.getCreatedBy().equals(userId)){
                throw new RuntimeException("You are the owner of this group");
            }else{
                group.getMembers().remove(userId);
                group.getBannedUsers().add(userId);
                notificationService.sendNotification(userId, "You have been banned from group "+ group.getName());
            }
            }else{
                notificationService.sendNotification(userId, "Your request to join group "+ group.getName() +" has been rejected");
            }
            group.getPendingRequests().remove(userId);
            groupRepository.save(group);
            return ResponseEntity.ok().build();
        } catch (Exception e) {
            throw new RuntimeException("Group not found");
        }
    }

    @Override
    public ResponseEntity<?> getGroupRequests(String groupId) {
        try {
            Group group = groupRepository.findById(groupId).get();
            if(!checkLoggedInUser(group.getCreatedBy())){
                throw new RuntimeException("You are not authorized to perform this action");
            }
            List<Profile> pendingRequests = group.getPendingRequests().stream()
                    .map(profileRepository::findByUserId)
                    .toList();;
            return ResponseEntity.ok(pendingRequests);
        } catch (Exception e) {
            throw new RuntimeException("Group not found");
        }
    }

    @Override
    public ResponseEntity<?> getGroupMembers(String groupId) {
        try {
            Group group = groupRepository.findById(groupId).get();
            List<Profile> members = group.getMembers().stream()
                    .map(profileRepository::findByUserId)
                    .toList();;
            return ResponseEntity.ok(members);
        } catch (Exception e) {
            throw new RuntimeException("Group not found");
        }
    }


    @Override
    public ResponseEntity<?> banUserFromGroup(String groupId, String userId) {
        try {
            Group group = groupRepository.findById(groupId).get();
            if (checkLoggedInUser(group.getCreatedBy())) {
                throw new RuntimeException("You are not authorized to perform this action");
            }
            group.getMembers().remove(userId);
            group.getPendingRequests().remove(userId);
            group.getBannedUsers().add(userId);
            notificationService.sendNotification(userId, "You have been banned from group "+ group.getName());
            groupRepository.save(group);
            return ResponseEntity.ok().build();
        } catch (Exception e) {
            throw new RuntimeException("Group not found");
        }
    }

    @Override
    public List<GroupResponse> searchGroups(String query) {
        try {
            List<Group> groups = groupRepository.findAll();
            return groups.stream()
                    .filter(group -> group.getName().contains(query) || group.getDescription().contains(query))
                    .map(this::constructGroupResponse)
                    .toList();
        } catch (Exception e) {
            throw new RuntimeException("Groups not found");
        }
    }

    @Override
    public ResponseEntity<?> sendRequestToGroup(String groupId) {
        try {
            Group group = groupRepository.findById(groupId).get();
            String userId = commonUtils.getUserId().toString();
            if(group.getCreatedBy().equalsIgnoreCase(userId)){
                throw new RuntimeException("You are the owner of this group");
            }
            if(group.getBannedUsers().contains(userId)){
                throw new RuntimeException("You are banned from this group");
            }
            group.getPendingRequests().add(commonUtils.getUserId().toString());
            groupRepository.save(group);
            return ResponseEntity.ok().build();
        } catch (Exception e) {
            throw new RuntimeException(e.getMessage());
        }
    }

    @Override
    public ResponseEntity<List<GroupResponse>> getMyGroups() {
        try{
            List<Group> groups = groupRepository.findAll();
            List<GroupResponse> groupResponses = new ArrayList<>();
            for (Group group : groups) {
                if(group.getMembers().contains(commonUtils.getUserId().toString())){
                    GroupResponse constructGroupResponse = constructGroupResponse(group);
                    groupResponses.add(constructGroupResponse);
                }
            }
            return ResponseEntity.ok(groupResponses);
        }catch (Exception e) {
            throw new RuntimeException("Groups not found");
        }
    }

    @Override
    public ResponseEntity<List<GroupResponse>> getNonApprovedGroups() {
        try{
            List<Group> groups = groupRepository.findAll();
            List<GroupResponse> groupResponses = new ArrayList<>();

            groups.stream().filter(group -> !group.isVerified()).forEach(group -> {
                GroupResponse constructGroupResponse = constructGroupResponse(group);
                groupResponses.add(constructGroupResponse);
            });
            return ResponseEntity.ok(groupResponses);
        }catch (Exception e) {
            throw new RuntimeException("Groups not found");
        }
    }

    @Override
    public ResponseEntity<?> approveGroup(String groupId) {
        try {
            Group group = groupRepository.findById(groupId).get();
            group.setVerified(true);
            groupRepository.save(group);
            return ResponseEntity.ok().build();
        } catch (Exception e) {
            throw new RuntimeException("Group not found");
        }
    }

    @Override
    public ResponseEntity<?> cancelRequestToGroup(String groupId) {
        try{
            Group group = groupRepository.findById(groupId).get();
            group.getPendingRequests().remove(commonUtils.getUserId().toString());
            groupRepository.save(group);
            return ResponseEntity.ok().build();
        }catch (Exception e){
            throw new RuntimeException("Group not found");
        }
    }

    @Override
    public ResponseEntity<?> unfollowGroup(String groupId) {
        try{
            Group group = groupRepository.findById(groupId).get();
            group.getMembers().remove(commonUtils.getUserId().toString());
            Profile profile = profileRepository.findByUserId(commonUtils.getUserId().toString());
            profile.getGroups().remove(groupId);
            profileRepository.save(profile);
            groupRepository.save(group);
            return ResponseEntity.ok().build();
        }catch (
                Exception e){
            throw new RuntimeException("Group not found");
        }

    }

    @Override
    public ResponseEntity<?> getBannedMembers(String groupId) {
        try{
            Group group = groupRepository.findById(groupId).get();
            List<Profile> bannedUsers = group.getBannedUsers().stream()
                    .map(profileRepository::findByUserId)
                    .toList();;
            return ResponseEntity.ok(bannedUsers);
        }catch (Exception e){
            throw new RuntimeException("Group not found");
        }
    }

    @Override
    public ResponseEntity<?> removeUserFromGroup(String groupId, String userId) {
        try{
            Group group = groupRepository.findById(groupId).get();
            if(!checkLoggedInUser(group.getCreatedBy())){
                throw new RuntimeException("You are not authorized to perform this action");
            }
            group.getMembers().remove(userId);
            Profile profile = profileRepository.findByUserId(userId);
            profile.getGroups().remove(groupId);
            profileRepository.save(profile);
            groupRepository.save(group);
            return ResponseEntity.ok().build();
        }catch (Exception e) {
            throw new RuntimeException("Group not found");
        }
    }

    private GroupResponse constructGroupResponse(Group group) {
        boolean isEdit = false;
        String groupStatus = "";
        if(commonUtils.getUserId().toString().equals(group.getCreatedBy())){
            isEdit=true;
        }
        if(!isEdit){
            if(group.getMembers().contains(commonUtils.getUserId().toString())) {
                groupStatus = "member";
            } else if (group.getPendingRequests().contains(commonUtils.getUserId().toString())) {
                groupStatus = "pending";
            } else if (group.getBannedUsers().contains(commonUtils.getUserId().toString())) {
                groupStatus = "banned";
            } else {
                groupStatus = "none";
            }
        }
        List<Profile> members = null;
        List<Profile> pendingRequests = null;
        List<Profile> bannedUsers = null;
        if (!group.getMembers().isEmpty()) {
           members = group.getMembers().stream()
                    .map(profileRepository::findByUserId)
                    .toList();
        }

        if (!group.getPendingRequests().isEmpty() || group.getPendingRequests() != null) {
            pendingRequests =group.getPendingRequests().stream()
                    .map(profileRepository::findByUserId)
                    .toList();
        }

        if (!group.getBannedUsers().isEmpty() || group.getBannedUsers() != null) {
            bannedUsers = group.getBannedUsers().stream()
                    .map(profileRepository::findByUserId)
                    .toList();
        }

        GroupResponse groupResponse = new GroupResponse();
        groupResponse.setGroupId(group.getId());
        groupResponse.setVerified(group.isVerified());
        groupResponse.setName(group.getName());
        groupResponse.setProfileImage(group.getProfileImage());
        groupResponse.setCoverImage(group.getCoverImage());
        groupResponse.setCreatedBy(group.getCreatedBy());
        groupResponse.setMembers(members);
        groupResponse.setDescription(group.getDescription());
        groupResponse.setVisibility(group.getVisibility());
        groupResponse.setCreatedAt(group.getCreatedAt());
        groupResponse.setUpdatedAt(group.getUpdatedAt());
        groupResponse.setPendingRequests(pendingRequests);
        groupResponse.setBannedUsers(bannedUsers);
        groupResponse.setFeatured(group.isFeatured());
        groupResponse.setEdit(isEdit);
        groupResponse.setGroupStatus(groupStatus);
        return groupResponse;
    }

    private boolean checkLoggedInUser(String userId) {
        return commonUtils.getUserId().toString().equals(userId);
    }
}
