package com.app.universityblog.main.controller;


import com.app.universityblog.main.models.Group;
import com.app.universityblog.main.payload.request.GroupRequest;
import com.app.universityblog.main.payload.response.GroupResponse;
import com.app.universityblog.main.service.GroupService;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/group")
public class GroupController {

    private final GroupService groupService;

    public GroupController(GroupService groupService) {
        this.groupService = groupService;
    }

    @GetMapping("/all")
    public ResponseEntity<List<GroupResponse>> getAllGroups() {
        return groupService.getGroups();
    }

    @PostMapping("/")
    public ResponseEntity<?> createGroup(@RequestBody GroupRequest group) {
        return groupService.createGroup(group);
    }

    @PatchMapping("/sendRequest/{groupId}")
    public ResponseEntity<?> sendRequestToGroup(@PathVariable("groupId") String groupId) {
        return groupService.sendRequestToGroup(groupId);
    }

    @PatchMapping("/cancelRequest/{groupId}")
    public ResponseEntity<?> cancelRequestToGroup(@PathVariable("groupId") String groupId) {
        return groupService.cancelRequestToGroup(groupId);
    }

    @PatchMapping("/unfollow/{groupId}")
    public ResponseEntity<?> unfollowGroup(@PathVariable("groupId") String groupId) {
        return groupService.unfollowGroup(groupId);
    }

    @GetMapping("/{groupId}")
    public ResponseEntity<GroupResponse> getGroupById(@PathVariable("groupId") String groupId) {
        return groupService.getGroupById(groupId);
    }

    @GetMapping("/myGroups")
    public ResponseEntity<List<GroupResponse>> getMyGroups() {
        return groupService.getMyGroups();
    }

    @DeleteMapping("/{groupId}")
    public ResponseEntity<?> deleteGroup(@PathVariable("groupId") String groupId) {
        return groupService.deleteGroup(groupId);
    }

    @PatchMapping("/{groupId}")
    public ResponseEntity<GroupResponse> updateGroup( @PathVariable("groupId") String groupId,@RequestBody Group group) {
        return groupService.updateGroup(groupId, group);
    }

    @GetMapping("/{groupId}/requests")
    public ResponseEntity<?> getGroupRequests(@PathVariable("groupId") String groupId) {
        return groupService.getGroupRequests(groupId);
    }

    @GetMapping("/{groupId}/members")
    public ResponseEntity<?> getGroupMembers(@PathVariable("groupId") String groupId) {
        return groupService.getGroupMembers(groupId);
    }

    @GetMapping("/{groupId}/bannedMembers")
    public ResponseEntity<?> getBannedMembers(@PathVariable("groupId") String groupId) {
        return groupService.getBannedMembers(groupId);
    }



    @GetMapping("/removeUserFromGroup/{groupId}/{userId}")
    public ResponseEntity<?> removeUserFromGroup(@PathVariable("groupId") String groupId,@PathVariable("userId") String userId) {
        return groupService.removeUserFromGroup(groupId, userId);
    }

    @PatchMapping("/{groupId}/{userId}/{status}")
    public ResponseEntity<?> updateRequestStatus(@PathVariable("groupId") String groupId,
                                                 @PathVariable("userId") String userId,
                                                 @PathVariable("status") String status) {
        return groupService.updateRequestStatus(groupId, userId, status);
    }


    @PatchMapping("/{groupId}/ban/{userId}")
    public ResponseEntity<?> banUserFromGroup(@PathVariable("groupId") String groupId,@PathVariable("userId") String userId) {
        return groupService.banUserFromGroup(groupId, userId);
    }


    @GetMapping("/getNonApprovedGroups")
    public ResponseEntity<List<GroupResponse>> getNonApprovedGroups() {
        return groupService.getNonApprovedGroups();
    }

    @PatchMapping("/{groupId}/approve")
    public ResponseEntity<?> approveGroup(@PathVariable("groupId") String groupId) {
        return groupService.approveGroup(groupId);
    }



}
