package com.app.universityblog.main.payload.response;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.List;

@AllArgsConstructor
@NoArgsConstructor
@Data
public class SearchResponse {
    List<PostResponse> posts;
    List<GroupResponse> groups;
    List<UserResponse> profiles;
}
