package com.app.universityblog.main.repository;


import com.app.universityblog.main.models.Post;
import com.app.universityblog.main.models.Profile;
import org.springframework.data.mongodb.repository.MongoRepository;
import org.springframework.data.mongodb.repository.Query;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface ProfileRepository extends MongoRepository<Profile,String> {
    Profile findByUserId(String userId);

    @Query("{$text: {$search: ?0}}")
    List<Post> searchText(String searchTerm);

    List<Profile> findAllByUserId(List<String> members);
}
