package com.app.universityblog.main.controller;



import com.app.universityblog.main.models.File;
import com.app.universityblog.main.models.Attachment;
import com.app.universityblog.main.payload.request.ImageRequest;
import com.app.universityblog.main.service.FileService;
import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;

import java.io.IOException;

@RestController
//@CrossOrigin("*")

public class FileController {

    private final FileService fileService;

    public FileController(FileService fileService) {
        this.fileService = fileService;
    }

    @PostMapping("/file/upload")
    public ResponseEntity<File> upload(@RequestParam("file") MultipartFile file) throws IOException {
        return ResponseEntity.ok(fileService.uploadFile(file));
    }

    @GetMapping("/file/{id}")
    public ResponseEntity<byte[]> getFile(@PathVariable String id, @RequestParam("view") boolean view) {
        File file = fileService.getFile(id);
        String contentDisposition = view ? "inline" : "attachment";
        return ResponseEntity.ok()
                .contentType(MediaType.parseMediaType((String) file.getMetaData()))
                .header(HttpHeaders.CONTENT_DISPOSITION, contentDisposition
                        + "; filename=\"" + file.getFilename() + "\"")
                .body(file.getContent());
    }

    @GetMapping("/image/{id}")
    public ResponseEntity<byte[]> getImage(@PathVariable String id) throws IOException {
        Attachment image = fileService.getImage(id);
        String contentDisposition = "inline";
        return ResponseEntity.ok()
                .contentType(MediaType.IMAGE_PNG)
                .body(image.getContent());
    }

    @PostMapping("/image/upload")
    public ResponseEntity<String> uploadImage(@RequestBody ImageRequest imageRequest) throws IOException {
        return ResponseEntity.ok(fileService.saveImage(imageRequest.getImage()));
    }

}
