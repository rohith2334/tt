package com.app.universityblog.main.service;

import com.app.universityblog.main.payload.response.UserResponse;
import org.springframework.http.ResponseEntity;

import java.util.List;

public interface UserService {
    ResponseEntity<String> getProfilePic();

    ResponseEntity<UserResponse> getUserById(String userId);

   List<String> getAllUserIds();

    ResponseEntity<List<UserResponse>> getAllUsers();

    ResponseEntity<?> savePost(String postId);

    ResponseEntity<List<UserResponse>> getNonApprovedUsers();

    ResponseEntity<?> approveUser(String userId);
}
