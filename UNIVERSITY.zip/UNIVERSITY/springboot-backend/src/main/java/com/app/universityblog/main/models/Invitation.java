package com.app.universityblog.main.models;


import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import nonapi.io.github.classgraph.json.Id;
import org.springframework.data.mongodb.core.mapping.Document;

@AllArgsConstructor
@NoArgsConstructor
@Data
@Document(collection = "invitation")
public class Invitation {
    @Id
    private String id;
    private String senderId;
    private String receiverId;
    private String status;
}
