package com.app.universityblog.main.payload.response;


import com.app.universityblog.main.models.Profile;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.Date;
import java.util.List;

@AllArgsConstructor
@NoArgsConstructor
@Data
public class GroupResponse {
    private String groupId;
    private String name;
    private String createdBy;
    private List<Profile> members;
    private String admin;
    private Object setting;
    private String profileImage;
    private String coverImage;
    private String description;
    private List<String> tags;
    private String visibility;
    private Date createdAt;
    private Date updatedAt;
    private List<Profile> pendingRequests;
    private List<Profile> bannedUsers;
    private boolean featured;
    private boolean isVerified;
    private boolean isEdit;
    private String groupStatus;
}
