package com.app.universityblog.main.controller;


import com.app.universityblog.main.payload.response.UserResponse;
import com.app.universityblog.main.service.ProfileService;
import com.app.universityblog.main.service.UserService;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/user")
public class UserController {

    private final UserService userService;

    private final ProfileService profileService;

    public UserController(UserService userService,ProfileService profileService) {
        this.userService = userService;
        this.profileService=profileService;
    }

    @GetMapping("/profilePicture")
    public ResponseEntity<String> getProfilePicture() {
        return userService.getProfilePic();
    }

    @GetMapping("/{userId}")
    public ResponseEntity<UserResponse> getUserById(@PathVariable("userId") String userId) {
        return userService.getUserById(userId);
    }

    @GetMapping("/")
    public ResponseEntity<UserResponse> getUserById() {
        return userService.getUserById(null);
    }

    @GetMapping("/all")
    public ResponseEntity<List<UserResponse>> getAllUsers() {
        return userService.getAllUsers();
    }

    @GetMapping("/friends")
    public ResponseEntity<List<UserResponse>> getFriends() {
        return profileService.getFriends();
    }

    @GetMapping("/friendRequests")
    public ResponseEntity<List<UserResponse>> getFriendRequests() {
        return profileService.getFriendRequests();
    }

    @PatchMapping("/sendFriendRequest/{friendId}")
    public ResponseEntity<?> sendFriendRequest(@PathVariable("friendId") String friendId) {
        return profileService.sendFriendRequest(friendId);
    }

    @PatchMapping("/respondFriendRequest/{friendId}/{response}")
    public ResponseEntity<?> respondFriendRequest(@PathVariable("friendId") String friendId, @PathVariable("response") String response) {
        return profileService.respondFriendRequest(friendId, response);
    }

    @GetMapping("/sentRequests")
    public ResponseEntity<List<String>> getSentRequests() {
        return profileService.getSentRequests();
    }

    @DeleteMapping("/deleteFriendRequest/{friendId}")
    public ResponseEntity<?> deleteFriendRequest(@PathVariable("friendId") String friendId) {
        return profileService.deleteFriendRequest(friendId);
    }

    @PatchMapping("/unFriend/{friendId}")
    public ResponseEntity<?> unFriend(@PathVariable("friendId") String friendId) {
        return profileService.unFriend(friendId);
    }

    @PatchMapping("/block/{friendId}")
    public ResponseEntity<?> block(@PathVariable("friendId") String friendId) {
        return profileService.block(friendId);
    }

    @GetMapping("/friendSuggestion")
    public ResponseEntity<?> getFriendSuggestion() {
        return profileService.getFriendSuggestion();
    }



    @PatchMapping("/savePost/{postId}")
    public ResponseEntity<?> savePost(@PathVariable("postId") String postId) {
        return userService.savePost(postId);
    }


    @GetMapping("/getNonApprovedUsers")
    public ResponseEntity<List<UserResponse>> getNonApprovedUsers() {
        return userService.getNonApprovedUsers();
    }

    @PatchMapping("/{userId}/approve")
    public ResponseEntity<?> approveUser(@PathVariable("userId") String userId) {
        return userService.approveUser(userId);
    }


}
