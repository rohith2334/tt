package com.app.universityblog.main.service;


import com.app.universityblog.main.models.Notification;
import org.springframework.http.ResponseEntity;

import java.util.List;

public interface NotificationService {
    void sendNotification(String receieverId, String message);
    void markAsRead(String notificationId);
    void deleteNotification(String notificationId);
    ResponseEntity<List<Notification>> getNotifications(String userId);
}
