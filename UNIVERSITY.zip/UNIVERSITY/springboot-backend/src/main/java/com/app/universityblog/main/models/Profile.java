package com.app.universityblog.main.models;


import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.index.TextIndexed;

import java.util.HashMap;
import java.util.List;

@AllArgsConstructor
@NoArgsConstructor
@Data
@Builder
public class Profile {
    @Id
    private String id;
    private String userId;
    @TextIndexed
    private String userName;
    private String email;
    private String phoneNumber;
    private String firstName;
    private String lastName;
    private boolean isVerified;
    @TextIndexed
    private String bio;
    private HashMap<String,String> socials;
    private String createdAt;
    private String updatedAt;
    private String active;
    private String profilePicture;
    private List<String> savedPosts;
    private List<String> friendsList;
    private List<String> bannedUsers;
    private List<String> groupsList;
    private List<String> groups;
}
