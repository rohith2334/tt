package com.app.universityblog.main.controller;

import com.app.universityblog.main.models.Post;
import com.app.universityblog.main.payload.response.SearchResponse;
import com.app.universityblog.main.repository.GroupRepository;
import com.app.universityblog.main.repository.PostRepository;
import com.app.universityblog.main.repository.ProfileRepository;
import com.app.universityblog.main.service.GroupService;
import com.app.universityblog.main.service.PostService;
import com.app.universityblog.main.service.ProfileService;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/search")
public class SearchController {

    private final ProfileService profileService;

    private final GroupService groupService;

    private final PostService postService;

    public SearchController(ProfileService profileService, GroupService groupService, PostService postService) {

        this.profileService = profileService;
        this.groupService = groupService;
        this.postService = postService;
    }


    @GetMapping("")
    public ResponseEntity<SearchResponse> searchPosts(@RequestParam("term") String searchTerm,
                                                      @RequestParam(value = "group",defaultValue = "true") boolean group,
                                                      @RequestParam(value = "profile",defaultValue = "true") boolean profile,
                                                      @RequestParam(value ="post",defaultValue = "false ") boolean post) {
        try{
            SearchResponse searchResponse = new SearchResponse();
            if(post){
                searchResponse.setPosts(postService.searchPosts(searchTerm));


            }
            if(group){
                searchResponse.setGroups(groupService.searchGroups(searchTerm));
            }
            if(profile){
                searchResponse.setProfiles(profileService.searchUsers(searchTerm));
            }
            return ResponseEntity.ok(searchResponse);
        }catch (Exception e) {
            throw new RuntimeException("Search failed");
        }
    }


}
