package com.app.universityblog.main.controller;


import com.app.universityblog.main.models.Comment;
import com.app.universityblog.main.payload.request.PostRequest;
import com.app.universityblog.main.payload.response.PostResponse;
import com.app.universityblog.main.service.PollService;
import com.app.universityblog.main.service.PostService;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/post")
public class PostController {

    private final PostService postService;
    private final PollService pollService;

    public PostController(PostService postService, PollService pollService) {
        this.postService = postService;
        this.pollService = pollService;
    }

    @PostMapping("/")
    public void createPost(@RequestBody PostRequest postRequest) {
        postService.createPost(postRequest);
    }

    @GetMapping("/all")
    public ResponseEntity<?> getAllPosts() {
        return postService.getAllPosts();
    }

    @GetMapping("/user")
    public ResponseEntity<?> getPostsForLoggedInUser(@RequestParam(value = "friends", defaultValue = "false") boolean friends,
                                                     @RequestParam(value = "mine", defaultValue = "false") boolean mine,
                                                     @RequestParam(value = "group", defaultValue = "false") boolean group) {
        return postService.getPostsByUserId(null, friends);
    }

    @GetMapping("/user/{userId}")
    public ResponseEntity<?> getPostsByUserId(@PathVariable("userId") String userId
            , @RequestParam(value = "friends", defaultValue = "false") boolean friends,
                                              @RequestParam(value = "mine", defaultValue = "false") boolean mine,
                                              @RequestParam(value = "group", defaultValue = "false") boolean group) {
        return postService.getPostsByUserId(userId, friends);
    }

    @GetMapping("/{postId}")
    public ResponseEntity<PostResponse> getPostById(@PathVariable("postId") String postId) {
        return postService.getPostById(postId);

    }

    @PatchMapping("/{postId}")
    public ResponseEntity<?> updatePost(@RequestParam("postId") String postId, @RequestBody PostResponse postResponse) {
        return postService.updatePost(postResponse);
    }

    @DeleteMapping("/{postId}")
    public ResponseEntity<?> deletePost(@PathVariable("postId") String postId) {
        return postService.deletePost(postId);
    }

    @PostMapping("/{postId}/comment")
    public ResponseEntity<?> commentOnPost(@PathVariable("postId") String postId, @RequestBody Comment comment) {
        return postService.commentOnPost(postId, comment);
    }


    @PatchMapping("/{postId}/like")
    public ResponseEntity<?> likePost(@PathVariable("postId") String postId) {
        return postService.likePost(postId);
    }

    @PatchMapping("/{postId}/poll")
    public ResponseEntity<?> votePoll(@PathVariable("postId") String postId, @RequestParam("option") String option) {
        return pollService.vote(postId, option);
    }

}
