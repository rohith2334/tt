package com.app.universityblog.main.service;

import com.app.universityblog.main.exception.ResourceNotFoundException;
import com.app.universityblog.main.models.File;
import com.app.universityblog.main.models.Attachment;
import com.app.universityblog.main.repository.FileRepository;
import com.app.universityblog.main.repository.ImageRepository;
import org.bson.types.ObjectId;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;

import java.io.IOException;
import java.util.Base64;
import java.util.Optional;


@Service
public class FileServiceImpl implements  FileService{



    private FileRepository fileRepository;

    private ImageRepository imageRepository;


    public  FileServiceImpl(FileRepository fileRepository,ImageRepository imageRepository){
        this.fileRepository = fileRepository;
        this.imageRepository=imageRepository;
    }

    @Override
    public String saveImage(String base64Image) throws IOException {
        if (base64Image.contains("base64"   )) {
            String[] parts = base64Image.split(",");
            if (parts.length > 1) {
                base64Image = parts[1];
            }
        }
        System.out.println("Saving image");
        System.out.println(base64Image);
        try{
            byte[] imageBytes = Base64.getDecoder().decode(base64Image);
            Attachment image = Attachment.builder()
                    .content(imageBytes)
                    .filename(new ObjectId().toString())
                    .length(imageBytes.length)
                    .metaData("image/png")
                    .build();
            return imageRepository.save(image).getId();
        }catch (Exception e){
            e.printStackTrace();
            return "Error saving image";
        }
    }

    @Override
    public Attachment getImage(String imageId) throws IOException {
        Optional<Attachment> imageOptional = imageRepository.findById(imageId);
        if(imageOptional.isPresent()){
            return imageOptional.get();
        }
        throw new ResourceNotFoundException("please check file id");

    }

    @Override
    public String getFileName(String fileId) {
        Optional<File> fileOptional = fileRepository.findById(fileId);
        if(fileOptional.isPresent()){
            return fileOptional.get().getFilename();
        }
        throw new ResourceNotFoundException("please check file id");
    }

    @Override
public File uploadFile(MultipartFile multipartFile) throws IOException {
    System.out.println("Uploading image");
    // remove time and space from file name
    String fileName = multipartFile.getOriginalFilename().replaceAll(" ", "_").replaceAll(":", "_");
    // sanitize filename by replacing non-breaking spaces with regular spaces
    fileName = fileName.replace((char) 8239, ' ');
    // further sanitize filename by removing any characters outside the permitted range
    fileName = fileName.replaceAll("[^\\x00-\\xFF]", "");

    File file = File.builder()
            .content(multipartFile.getBytes())
            .filename(fileName)
            .length(multipartFile.getSize())
            .metaData(multipartFile.getContentType())
            .build();
    // save and return file
    return fileRepository.save(file);
}

    @Override
    public File getFile(String id) {
        Optional<File> fileOptional = fileRepository.findById(id);
        if(fileOptional.isPresent()){
            return fileOptional.get();
        }
        throw new ResourceNotFoundException("please check file id");
    }


}
