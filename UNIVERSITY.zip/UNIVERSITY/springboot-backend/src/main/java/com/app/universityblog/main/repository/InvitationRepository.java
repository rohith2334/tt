package com.app.universityblog.main.repository;

import com.app.universityblog.main.models.Invitation;
import org.springframework.data.mongodb.repository.MongoRepository;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface InvitationRepository extends MongoRepository<Invitation,String> {
    List<Invitation> findBySenderId(String string);
    List<Invitation> findByReceiverId(String string);
    List<Invitation> findBySenderIdAndReceiverId(String senderId, String receiverId);
//    void deleteBySenderIdAndReceiverId(String senderId, String receiverId);
}
