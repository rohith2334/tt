package com.app.universityblog.main.payload.response;


import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.HashMap;
import java.util.List;

@AllArgsConstructor
@NoArgsConstructor
@Data
@Builder
public class UserResponse {
    private String userId;
    private String userName;
    private boolean verified;
    private String email;
    private String phoneNumber;
    private String firstName;
    private String lastName;
    private String bio;
    private HashMap<String,String> socials;
    private String createdAt;
    private String updatedAt;
    private String active;
    private String profilePicture;
    private List<String> savedPosts;
    private List<String> friendsList;
    private List<String> pendingRequests;
    private List<String> bannedUsers;
    private List<String> groups;
    private boolean isVerified;
    private boolean isEdit;
    private String friendStatus;
}
