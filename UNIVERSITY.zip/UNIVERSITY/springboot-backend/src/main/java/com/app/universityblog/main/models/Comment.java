package com.app.universityblog.main.models;


import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import nonapi.io.github.classgraph.json.Id;
import org.springframework.data.mongodb.core.mapping.Document;

import java.util.Date;

@AllArgsConstructor
@NoArgsConstructor
@Data
@Document(collection = "comments")
public class Comment {
    @Id
    private String id;
    private String userId;
    private String username;
    private String profilePic;
    private String message;
    private String likes;
    private Date createdAt;
    private Date updatedAt;

}
