package com.app.universityblog.main.service;

import com.app.universityblog.main.models.Poll;
import org.springframework.http.ResponseEntity;

public interface PollService {

    Poll postPoll(Poll poll);

    ResponseEntity<?> vote(String postId, String option);


    Poll getPollById(String poll);
}
