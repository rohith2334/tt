package com.app.universityblog.main.service;


import com.app.universityblog.common.utils.CommonUtils;
import com.app.universityblog.main.models.Poll;
import com.app.universityblog.main.models.Post;
import com.app.universityblog.main.repository.PollRepository;
import com.app.universityblog.main.repository.PostRepository;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class PollServiceImpl implements PollService {

    private final PollRepository pollRepository;
    private final PostRepository postRepository;
    private final CommonUtils commonUtils;

    public PollServiceImpl(PollRepository pollRepository, PostRepository postRepository, CommonUtils commonUtils) {
        this.pollRepository = pollRepository;
        this.postRepository = postRepository;
        this.commonUtils = commonUtils;
    }


    @Override
    public Poll postPoll(Poll poll) {
        try {
            poll.getOptions().forEach(pollOption -> {
                pollOption.setVotes(0);
                pollOption.setVoters(List.of());
            });
            return pollRepository.save(poll);
        } catch (Exception e) {
            e.printStackTrace();
            return null;
        }
    }

    @Override
    public ResponseEntity<?> vote(String postId, String option) {
        try {
            String userID = commonUtils.getUserId().toString();
            Post post = postRepository.findById(postId).get();
            Poll poll = pollRepository.findById(post.getPoll()).get();
            if(poll.getVotedUserIds().contains(userID)) {
                return ResponseEntity.ok().body("You have already voted");
            }
            poll.getOptions().stream()
                    .filter(pollOption -> pollOption.getOptionText().equals(option))
                    .forEach(pollOption -> {
                        pollOption.setVotes(pollOption.getVotes() + 1);
                        pollOption.getVoters().add(userID);
                    });
            poll.getVotedUserIds().add(userID);
            poll.setTotalVotes(poll.getTotalVotes() + 1);
            pollRepository.save(poll);
            return ResponseEntity.ok("Voted successfully");
        } catch (Exception e) {
            e.printStackTrace();
            return ResponseEntity.badRequest().body("Error voting");
        }
    }

    @Override
        public Poll getPollById(String poll) {
        try {
            String userID = commonUtils.getUserId().toString();
            Poll _poll=  pollRepository.findById(poll).get();
            _poll.getOptions().stream()
                    .filter(pollOption -> pollOption.getVoters().contains(userID))
                    .forEach(pollOption -> _poll.setOptionSelected(pollOption.getOptionText()));
            return _poll;
        } catch (Exception e) {
            e.printStackTrace();
            return null;
        }
    }
}
