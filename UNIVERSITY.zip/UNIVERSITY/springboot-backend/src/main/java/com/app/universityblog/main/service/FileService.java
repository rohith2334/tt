package com.app.universityblog.main.service;

import com.app.universityblog.main.models.File;
import com.app.universityblog.main.models.Attachment;
import org.springframework.web.multipart.MultipartFile;

import java.io.IOException;

public interface FileService {

     String saveImage(String base64Image) throws IOException;

     Attachment getImage(String imageId) throws IOException;

     String getFileName(String fileId);

     File uploadFile(MultipartFile file) throws IOException;

     File getFile(String id);
}
