package com.app.universityblog.main.payload.request;


import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@AllArgsConstructor
@NoArgsConstructor
@Data
public class GroupRequest {
    private String name;
    private String profileImage;
    private String coverImage;
    private String description;
}
