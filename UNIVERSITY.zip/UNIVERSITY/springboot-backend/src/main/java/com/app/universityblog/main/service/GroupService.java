package com.app.universityblog.main.service;

import com.app.universityblog.main.models.Group;
import com.app.universityblog.main.payload.request.GroupRequest;
import com.app.universityblog.main.payload.response.GroupResponse;
import com.app.universityblog.main.payload.response.UserResponse;
import org.springframework.http.ResponseEntity;

import java.util.List;

public interface GroupService {
    ResponseEntity<?> createGroup(GroupRequest group);

    ResponseEntity<GroupResponse> getGroupById(String groupId);

    ResponseEntity<List<GroupResponse>> getGroups();

    ResponseEntity<?> deleteGroup(String groupId);

    ResponseEntity<GroupResponse> updateGroup(String groupId, Group group);


    ResponseEntity<?> updateRequestStatus(String groupId, String userId,String status);

    ResponseEntity<?> getGroupRequests(String groupId);

    ResponseEntity<?> getGroupMembers(String groupId);

//    ResponseEntity<?> getGroupPosts(String groupId);

    ResponseEntity<?> banUserFromGroup(String groupId, String userId);


    List<GroupResponse> searchGroups(String query);

    ResponseEntity<?> sendRequestToGroup(String groupId);

    ResponseEntity<List<GroupResponse>> getMyGroups();

    ResponseEntity<List<GroupResponse>> getNonApprovedGroups();

    ResponseEntity<?> approveGroup(String groupId);

    ResponseEntity<?> cancelRequestToGroup(String groupId);

    ResponseEntity<?> unfollowGroup(String groupId);

    ResponseEntity<?> getBannedMembers(String groupId);

    ResponseEntity<?> removeUserFromGroup(String groupId, String userId);
}
