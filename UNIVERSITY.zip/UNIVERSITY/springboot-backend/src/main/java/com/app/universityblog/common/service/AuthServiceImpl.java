package com.app.universityblog.common.service;

import com.app.universityblog.common.models.Admin;
import com.app.universityblog.common.models.ERole;
import com.app.universityblog.common.models.Role;
import com.app.universityblog.common.models.User;
import com.app.universityblog.common.payload.request.LoginRequest;
import com.app.universityblog.common.payload.request.SignupRequest;
import com.app.universityblog.common.payload.response.MessageResponse;
import com.app.universityblog.common.payload.response.UserInfoResponse;
import com.app.universityblog.common.repository.AdminRepository;
import com.app.universityblog.common.repository.RoleRepository;
import com.app.universityblog.common.repository.UserRepository;
import com.app.universityblog.common.security.jwt.JwtUtils;
import com.app.universityblog.common.security.services.UserDetailsImpl;
//import com.app.universityblog.main.service.UserService;
import com.app.universityblog.main.service.ProfileService;
import org.bson.types.ObjectId;
import org.springframework.http.HttpHeaders;
import org.springframework.http.ResponseCookie;
import org.springframework.http.ResponseEntity;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;

import java.util.HashSet;
import java.util.List;
import java.util.Set;
import java.util.concurrent.atomic.AtomicBoolean;
import java.util.stream.Collectors;


@Service
public class AuthServiceImpl implements AuthService {
    private final AuthenticationManager authenticationManager;
    private final JwtUtils jwtUtils;
    private final UserRepository userRepository;
    private final RoleRepository roleRepository;
    private final PasswordEncoder encoder;



    private final ProfileService profileService;

    AuthServiceImpl(AuthenticationManager authenticationManager,AdminRepository   adminRepository, ProfileService profileService,JwtUtils jwtUtils, UserRepository userRepository, RoleRepository roleRepository, PasswordEncoder encoder) {
        this.authenticationManager = authenticationManager;
        this.jwtUtils = jwtUtils;
        this.userRepository = userRepository;
        this.roleRepository = roleRepository;
        this.encoder = encoder;
        this.profileService=profileService;

//        this.userService = userService;
    }

    @Override
    public ResponseEntity<?> registerUser(SignupRequest signUpRequest) {


        if (userRepository.existsByUsername(signUpRequest.getUsername())) {
            return ResponseEntity
                    .badRequest()
                    .body(new MessageResponse("Error: Username is already taken!"));
        }

        if (userRepository.existsByEmail(signUpRequest.getEmail())) {
            return ResponseEntity
                    .badRequest()
                    .body(new MessageResponse("Error: Email is already in use!"));
        }

        // Create new user's account
        User user = new User(signUpRequest.getUsername(),
                signUpRequest.getEmail(),
                encoder.encode(signUpRequest.getPassword()));
        if(signUpRequest.getRole()==null){
            signUpRequest.setRole("user");
        }
        Set<String> strRoles = Set.of(signUpRequest.getRole());
        Set<Role> roles = new HashSet<>();
        AtomicBoolean isAdmin= new AtomicBoolean(false);

        if (strRoles.isEmpty()) {
            Role userRole = roleRepository.findByName(ERole.ROLE_USER)
                    .orElseThrow(() -> new RuntimeException("Error: Role is not found."));
            roles.add(userRole);
        } else {
            strRoles.forEach(role -> {
                switch (role) {
                    case "admin":
                        Role adminRole = roleRepository.findByName(ERole.ROLE_ADMIN)
                                .orElseThrow(() -> new RuntimeException("Error: Role is not found."));
                        user.setVerified(true);
                        roles.add(adminRole);
                        isAdmin.set(true);
                        break;

                    default:
                        Role userRole = roleRepository.findByName(ERole.ROLE_USER)
                                .orElseThrow(() -> new RuntimeException("Error: Role is not found."));
//                        user.setVerified(true);
                        roles.add(userRole);
                }
            });
        }

        user.setRoles(roles);

        User _user= userRepository.save(user);
        signUpRequest.setUserId(_user.getId());
        //create realted profile and set it to user
        if(isAdmin.get()){
           profileService.createProfile(signUpRequest,true);

        }else{
            user.setProfile(new ObjectId(profileService.createProfile(signUpRequest,false)));
        }

       userRepository.save(user);

        return ResponseEntity.ok(new MessageResponse("User registered successfully!"));
    }

    @Override
    public ResponseEntity<?> authenticateUser(LoginRequest loginRequest) {
        Authentication authentication = authenticationManager.authenticate(
                new UsernamePasswordAuthenticationToken(loginRequest.getEmail(), loginRequest.getPassword()));
        User user = userRepository.findByEmail(loginRequest.getEmail()).get();
        SecurityContextHolder.getContext().setAuthentication(authentication);

        UserDetailsImpl userDetails = (UserDetailsImpl) authentication.getPrincipal();

        ResponseCookie jwtCookie = jwtUtils.generateJwtCookie(userDetails);
        System.out.println(jwtCookie);

        List<String> roles = userDetails.getAuthorities().stream()
                .map(item -> item.getAuthority())
                .collect(Collectors.toList());
        HttpHeaders headers = new HttpHeaders();
        return ResponseEntity.ok().header("X-JWT-Token", jwtCookie.toString())
                .header("Access-Control-Expose-Headers", "X-JWT-Token")
                .body(new UserInfoResponse(
                        userDetails.getId(),
                        userDetails.getUsername(),
                        userDetails.getEmail(),
                        roles.get(0), user.isVerified()));
    }


}
