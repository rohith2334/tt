package com.app.universityblog.main.service;


import com.app.universityblog.common.models.User;
import com.app.universityblog.common.repository.UserRepository;
import com.app.universityblog.common.utils.CommonUtils;
import com.app.universityblog.main.exception.ResourceNotFoundException;
import com.app.universityblog.main.models.Profile;
import com.app.universityblog.main.models.Invitation;
import com.app.universityblog.main.payload.response.UserResponse;
import com.app.universityblog.main.repository.ProfileRepository;
import com.app.universityblog.main.repository.InvitationRepository;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class UserServiceImpl implements UserService {

    private final UserRepository userRepository;

    private final ProfileRepository profileRepository;

    private  final CommonUtils commonUtils;

    private final InvitationRepository invitationRepository;

    public UserServiceImpl(UserRepository userRepository, ProfileRepository profileRepository, CommonUtils commonUtils, InvitationRepository requestsRepository) {
        this.userRepository = userRepository;
        this.profileRepository = profileRepository;
        this.commonUtils=commonUtils;
        this.invitationRepository = requestsRepository;
    }

    @Override
    public ResponseEntity<String> getProfilePic() {
        try{
            String userId=commonUtils.getUserId().toString();
            Profile profile = profileRepository.findByUserId(userId);
            if(profile==null){
                throw new ResourceNotFoundException("profile not found");
            }else{
                return ResponseEntity.ok(profile.getProfilePicture());
            }
        }catch (Exception e){
            return ResponseEntity.badRequest().body(null);
        }
    }

    @Override
    public ResponseEntity<UserResponse> getUserById(String userId) {
        try{
            if(userId==null){
                userId=commonUtils.getUserId().toString();
            }
            User user= userRepository.findById(userId).orElse(null);
            Profile profile = profileRepository.findByUserId(userId);
            List<Invitation> requests = invitationRepository.findByReceiverId(userId);
            if(user==null || profile==null){
                throw new ResourceNotFoundException("user not found");
            }else{
                return ResponseEntity.ok(constructUserResponse(user,profile,requests));
            }
        }catch (Exception e){
            return ResponseEntity.badRequest().body(null);
        }
    }

    @Override
    public List<String> getAllUserIds() {
       try{
              List<User> users = userRepository.findAll();
              users.removeIf(user -> user.getRoles().stream().anyMatch(role -> role.getName().name().equals("ROLE_ADMIN")));
           return users.stream().map(User::getId).toList();
       }catch (Exception e){
           throw new ResourceNotFoundException("Users not found");
       }
    }

    @Override
    public ResponseEntity<List<UserResponse>> getAllUsers() {
        try {
            List<User> users = userRepository.findAll();
            users.removeIf(user -> user.getRoles().stream().anyMatch(role -> role.getName().name().equals("ROLE_ADMIN")));
            List<UserResponse> userResponses = users.stream().map(user -> {
                Profile profile = profileRepository.findByUserId(user.getId());
                List<Invitation> requests = invitationRepository.findByReceiverId(user.getId());
                return constructUserResponse(user, profile,requests);
            }).toList();
            return ResponseEntity.ok(userResponses);
        } catch (Exception e) {
            return ResponseEntity.badRequest().body(null);
        }
    }

    @Override
    public ResponseEntity<?> savePost(String postId) {
        try{
            String userId=commonUtils.getUserId().toString();
            Profile profile = profileRepository.findByUserId(userId);
            if(profile==null){
                throw new ResourceNotFoundException("profile not found");
            }else{
                List<String> savedPosts = profile.getSavedPosts();
                savedPosts.add(postId);
                profile.setSavedPosts(savedPosts);
                profileRepository.save(profile);
                return ResponseEntity.ok().body("Post saved successfully");
            }
        }catch (Exception e) {
            return ResponseEntity.badRequest().body(null);
        }
    }

    @Override
    public ResponseEntity<List<UserResponse>> getNonApprovedUsers() {
        try{
            List<User> users =userRepository.findAll();
            List<UserResponse> userResponses = users.stream().filter(user -> !user.isVerified()).map(user -> {
                Profile profile = profileRepository.findByUserId(user.getId());
                List<Invitation> requests = invitationRepository.findByReceiverId(user.getId());
                return constructUserResponse(user,profile,requests);
            }).toList();
            return ResponseEntity.ok(userResponses);
        }catch (Exception e){
            return ResponseEntity.badRequest().body(null);
        }
    }

    @Override
    public ResponseEntity<?> approveUser(String userId) {
        try{
            User user = userRepository.findById(userId).orElse(null);
            if(user==null){
                throw new ResourceNotFoundException("user not found");
            }else{
                user.setVerified(true);
                userRepository.save(user);
                Profile profile = profileRepository.findByUserId(userId);
                profile.setVerified(true);
                profileRepository.save(profile);
                return ResponseEntity.ok().body("User approved successfully");
            }
        }catch (Exception e){
            return ResponseEntity.badRequest().body(null);
        }
    }


    private UserResponse constructUserResponse(User user, Profile profile,List<Invitation> pendingRequests){
        boolean isEdit = false;
        String friendStatus = "none";
        Profile _profile = profileRepository.findByUserId(commonUtils.getUserId().toString());
        if(commonUtils.getUserId().toString().equals(user.getId())){
            isEdit=true;
        }
        if(profile.getBannedUsers()==null){
            profile.setBannedUsers(List.of());
        }

        if(profile.getFriendsList()==null){
            profile.setFriendsList(List.of());
        }

        if (_profile.getBannedUsers()==null){
            _profile.setBannedUsers(List.of());
        }


        if(!isEdit){
            Invitation request = pendingRequests.stream().filter(invitation -> invitation.getSenderId().equals(commonUtils.getUserId().toString())).findFirst().orElse(null);
            if(request!=null){
                friendStatus="pending";
            }else if (profile.getFriendsList().contains(commonUtils.getUserId().toString())){
                friendStatus="friends";
            }else if(profile.getBannedUsers().contains(commonUtils.getUserId().toString()) ||
                        _profile.getBannedUsers().contains(profile.getUserId()) ) {
                friendStatus = "blocked";
            }
            else{
                friendStatus="none";
            }
        }

        return UserResponse.builder()
                .userId(user.getId())
                .userName(user.getUsername())
                .email(user.getEmail())
                .verified(profile.isVerified())
                .firstName(profile.getFirstName())
                .lastName(profile.getLastName())
                .profilePicture(profile.getProfilePicture())
                .phoneNumber(profile.getPhoneNumber())
                .active(profile.getActive())
                .createdAt(profile.getCreatedAt())
                .updatedAt(profile.getUpdatedAt())
                .savedPosts(profile.getSavedPosts())
                .bannedUsers(profile.getBannedUsers())
//                .friendsList(profile.getFriendsList())
//                .pendingRequests(pendingRequests.stream().map(Invitation::getSenderId).toList())
                .groups(profile.getGroups())
                .socials(profile.getSocials())
                .isEdit(isEdit)
                .friendStatus(friendStatus)
                .build();
    }
}
