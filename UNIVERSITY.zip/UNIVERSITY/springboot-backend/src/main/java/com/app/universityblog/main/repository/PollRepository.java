package com.app.universityblog.main.repository;


import com.app.universityblog.main.models.Poll;
import org.springframework.data.mongodb.repository.MongoRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface PollRepository extends MongoRepository<Poll,String> {
}
