package com.app.universityblog.main.payload.request;

import com.app.universityblog.main.models.Poll;
import com.app.universityblog.main.models.Post;
import com.app.universityblog.main.models.VisibilityStatus;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.Date;
import java.util.List;

@AllArgsConstructor
@NoArgsConstructor
@Data
public class PostRequest {
    private String groupId;
    private String content;
    private String topic;
    private List<String> images;
    private List<String> attachments;
    private Poll poll;
    private VisibilityStatus visibilityStatus;
//    private String commentFilter;


}
