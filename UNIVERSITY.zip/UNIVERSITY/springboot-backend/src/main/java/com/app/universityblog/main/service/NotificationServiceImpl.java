package com.app.universityblog.main.service;

import com.app.universityblog.common.models.User;
import com.app.universityblog.common.repository.UserRepository;
import com.app.universityblog.common.utils.CommonUtils;
import com.app.universityblog.common.utils.EmailService;
import com.app.universityblog.main.repository.NotificationRepository;
import com.app.universityblog.main.models.Notification;
import org.bson.types.ObjectId;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;

import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.stream.Collectors;


@Service
public class NotificationServiceImpl implements NotificationService{

    private NotificationRepository notificationRepository;

    private CommonUtils commonUtils;

    private EmailService emailService;

    private UserRepository userRepository;
    public NotificationServiceImpl(NotificationRepository notificationRepository,CommonUtils commonUtils, EmailService emailService,UserRepository userRepository) {
        this.notificationRepository = notificationRepository;
        this.commonUtils=commonUtils;
        this.userRepository=userRepository;
        this.emailService=emailService;
    }
    @Override
    public void sendNotification(String receieverId, String message){
        Notification notification = new Notification();
        notification.setSenderId(commonUtils.getUserId());
        notification.setReceiverId(new ObjectId(receieverId));
        notification.setMessage(message);
        notification.setIsRead(false);
        notification.setCreatedAt(commonUtils.getCurrentDate());
        notificationRepository.save(notification);
    }

    @Override
    public void markAsRead(String notificationId) {
        try {
            Notification notification = notificationRepository.findById(notificationId).get();
            notification.setIsRead(true);
            notificationRepository.save(notification);
        } catch (Exception e) {
            throw new RuntimeException("Error while marking notification as read");

        }

    }

    @Override
    public void deleteNotification(String notificationId) {

        try{
            notificationRepository.deleteById(notificationId);
        }catch (Exception e){
            throw new RuntimeException("Error while deleting notification");
        }

    }

    @Override
    public ResponseEntity<List<Notification>> getNotifications(String userId) {
       try {
            if(userId==null){
                userId=commonUtils.getUserId().toString();
            }
           List<Notification> notifications = notificationRepository.findByReceiverId(new ObjectId(userId));

           if (notifications.isEmpty()) {
               return ResponseEntity.ok().body(Collections.emptyList());
           } else {
               notifications=notifications.stream()
                       .filter(notification -> !notification.getIsRead()).collect(Collectors.toList());
               return ResponseEntity.ok().body(notifications);
           }
       }catch (Exception e){
           throw new RuntimeException("Error while fetching notifications");
       }
    }
}
