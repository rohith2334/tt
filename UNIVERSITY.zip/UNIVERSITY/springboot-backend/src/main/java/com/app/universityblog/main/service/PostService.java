package com.app.universityblog.main.service;

import com.app.universityblog.main.models.Comment;
import com.app.universityblog.main.payload.request.PostRequest;
import com.app.universityblog.main.payload.response.PostResponse;
import org.springframework.http.ResponseEntity;

import java.util.List;

public interface PostService {

    ResponseEntity<?> createPost(PostRequest postRequest);

    ResponseEntity<PostResponse> getPostById(String postId);

    ResponseEntity<?> updatePost(PostResponse postResponse);

    ResponseEntity<?> deletePost(String postId);

    ResponseEntity<List<PostResponse>> getAllPosts();

    ResponseEntity<List<PostResponse>> getPostsByUserId(String userId,boolean friends);

    ResponseEntity<?> likePost(String postId);

    List<PostResponse> searchPosts(String query);

    ResponseEntity<?> commentOnPost(String postId, Comment comment);
}
