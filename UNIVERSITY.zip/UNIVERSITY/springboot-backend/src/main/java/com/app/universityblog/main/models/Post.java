package com.app.universityblog.main.models;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import nonapi.io.github.classgraph.json.Id;
import org.springframework.data.mongodb.core.index.TextIndexed;
import org.springframework.data.mongodb.core.mapping.Document;

import java.util.Date;
import java.util.List;

@AllArgsConstructor
@NoArgsConstructor
@Data
@Document(collection = "posts")
public class Post {
    @Id
    private String id;
    private String authorId;
    private String groupId;
    @TextIndexed
    private String content;
    private String topic;
    private List<String> likes;
    private List<String> images;
    private List<String> comments;
    private Date timestamp;
    private List<String> attachments;
    //    private List<String> tags;
    private VisibilityStatus visibility;
    private Date createdAt;
    private Date updatedAt;
    private String poll;
//    private String commentFilter;

}
