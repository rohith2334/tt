package com.app.universityblog.common.models;

public enum ERole {
  ROLE_USER,
  ROLE_ADMIN
}
