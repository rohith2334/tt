package com.app.universityblog.main.models;

public enum VisibilityStatus {
    GROUP,
    FRIENDS,
    PUBLIC

}
