package com.app.universityblog.main.service;


import com.app.universityblog.common.utils.CommonUtils;
import com.app.universityblog.main.models.*;
import com.app.universityblog.main.payload.request.PostRequest;
import com.app.universityblog.main.payload.response.PostResponse;
import com.app.universityblog.main.payload.response.UserResponse;
import com.app.universityblog.main.repository.CommentRepository;
import com.app.universityblog.main.repository.FileRepository;
import com.app.universityblog.main.repository.GroupRepository;
import com.app.universityblog.main.repository.PostRepository;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;

import java.util.*;
import java.util.stream.Collectors;

@Service
public class PostServiceImpl implements PostService {

    private final PostRepository postRepository;

    private final GroupRepository groupRepository;

    private final CommentRepository commentRepository;

    private final FileRepository fileRepository;

    private final ProfileService profileService;
    private final PollService pollSevice;

    private final CommonUtils commonUtils;

    private final NotificationService notificationService;


    public PostServiceImpl(PostRepository postRepository, GroupRepository groupRepository, CommentRepository commentRepository, FileRepository fileRepository, ProfileService profileService, PollService pollSevice, CommonUtils commonUtils, NotificationService notificationService) {
        this.postRepository = postRepository;
        this.groupRepository = groupRepository;
        this.commentRepository = commentRepository;
        this.fileRepository = fileRepository;
        this.profileService = profileService;
        this.pollSevice = pollSevice;
        this.commonUtils = commonUtils;
        this.notificationService = notificationService;
    }

    @Override
    public ResponseEntity<?> createPost(PostRequest postRequest) {
        try {
            Poll poll = new Poll();
            if (postRequest.getPoll() != null && !postRequest.getPoll().getOption().isEmpty()){
                poll.setQuestion(postRequest.getPoll().getQuestion());
                poll.setVotedUserIds(List.of());
                List<Option> options = postRequest.getPoll().getOption().stream().map(option -> {
                    Option _option = new Option();
                    _option.setOptionText(option);
                    _option.setVotes(0);
                    return _option;
                }).toList();

                poll.setOptions(options);
                poll.setTotalVotes(0);
                poll = pollSevice.postPoll(poll);
            }

            Post post = new Post();
            post.setAuthorId(commonUtils.getUserId().toString());
            post.setGroupId(postRequest.getGroupId());
            post.setContent(postRequest.getContent());
            post.setTopic(postRequest.getTopic());
            post.setImages(postRequest.getImages());
            post.setAttachments(postRequest.getAttachments());
            if (postRequest.getVisibilityStatus() == null || postRequest.getVisibilityStatus().toString().equals(VisibilityStatus.PUBLIC.toString())) {
                post.setGroupId(null);
                post.setVisibility(VisibilityStatus.PUBLIC);
            } else if (postRequest.getVisibilityStatus().equals(VisibilityStatus.FRIENDS)) {
                post.setGroupId(null);
                post.setVisibility(VisibilityStatus.FRIENDS);
                UserResponse profile = profileService.getUserById(commonUtils.getUserId().toString()).getBody();
                String titleAndMessage = "New post from " + profile.getFirstName();
                profile.getFriendsList().forEach(friendId -> notificationService.sendNotification(friendId, titleAndMessage));
            } else {
                post.setVisibility(VisibilityStatus.GROUP);
                Group group = groupRepository.findById(postRequest.getGroupId()).orElse(null);
                if (group == null) {
                    return ResponseEntity.badRequest().body("Group not found");
                }
                UserResponse profile = profileService.getUserById(group.getCreatedBy()).getBody();
                String titleAndMessage = profile.getUserName() + "created a post in " + group.getName();
                group.getMembers().forEach(memberId -> notificationService.sendNotification(memberId, titleAndMessage));


            }

            post.setPoll(poll.getId());
            post.setLikes(List.of());
            post.setComments(List.of());
            post.setCreatedAt(new Date());
            post.setUpdatedAt(new Date());
            postRepository.save(post);
            return ResponseEntity.ok("Post created successfully");
        } catch (Exception e) {
            return ResponseEntity.badRequest().body("Error creating post");
        }
    }


    @Override
    public ResponseEntity<PostResponse> getPostById(String postId) {
        try {
            Post post = postRepository.findById(postId).orElse(null);
            if (post == null) {
                return ResponseEntity.badRequest().body(null);
            }
            return ResponseEntity.ok(getPostResponse(post));
        } catch (Exception e) {
            return ResponseEntity.badRequest().body(null);
        }
    }

    @Override
    public ResponseEntity<?> updatePost(PostResponse postResponse) {
        return null;
    }

    @Override
    public ResponseEntity<?> deletePost(String postId) {
        try {
            Post _post = postRepository.findById(postId).get();
            if (!checkLoggedInUser(_post.getAuthorId())) {
                return ResponseEntity.badRequest().body("You are not authorized to delete this post");
            }
            postRepository.deleteById(postId);
            return ResponseEntity.ok("Post deleted successfully");
        } catch (Exception e) {
            return ResponseEntity.badRequest().body("Error deleting post");
        }
    }

    @Override
    public ResponseEntity<List<PostResponse>> getAllPosts() {
        try {
            List<Post> posts = postRepository.findAll();
            List<PostResponse> postResponses = posts.stream()
                    .map(this::getPostResponse)
                    .collect(Collectors.toList());
            return ResponseEntity.ok(postResponses);
        } catch (Exception e) {
            return ResponseEntity.badRequest().body(null);
        }
    }

    @Override
    public ResponseEntity<List<PostResponse>> getPostsByUserId(String userId, boolean friends) {
        try {
            if (userId == null) {
                userId = commonUtils.getUserId().toString();
            }
            // Retrieve the user's profile
            UserResponse userResponse = profileService.getUserById(userId).getBody();
            if (userResponse == null) {
                return ResponseEntity.notFound().build();
            }

            // Get the list of groups the user is a member of
            List<String> userGroups = userResponse.getGroups();
            // Get the list of friends the user has
            List<String> userFriends = userResponse.getFriendsList();

            if (userResponse.getBannedUsers() == null) {
                userResponse.setBannedUsers(List.of());
            }
            List<String> bannedUsers = userResponse.getBannedUsers();

            // Retrieve all posts
            List<Post> allPosts = postRepository.findAll();
            List<Post> filteredPosts = null;
            if (!friends) {
                // Filter the posts based on the group membership and visibility
                filteredPosts = allPosts.stream()
                        .filter(post -> {
                            if (bannedUsers.contains(post.getAuthorId())) {
                                return false;
                            } else if (VisibilityStatus.PUBLIC.equals(post.getVisibility())) {
                                return true;
                            } else if (VisibilityStatus.GROUP.equals(post.getVisibility())) {
                                return userGroups.contains(post.getGroupId());
                            } else if (VisibilityStatus.FRIENDS.equals(post.getVisibility())) {
                                return userFriends.contains(post.getAuthorId());
                            } else {
                                return false;
                            }
                        })
                        .collect(Collectors.toList());
            } else {
                filteredPosts = allPosts.stream()
                        .filter(post -> {
                            if (VisibilityStatus.FRIENDS.equals(post.getVisibility())) {
                                return userFriends.contains(post.getAuthorId());
                            } else {
                                return false;
                            }
                        })
                        .collect(Collectors.toList());
            }

            // Convert each post to PostResponse
            List<PostResponse> postResponses = filteredPosts.stream()
                    .map(this::getPostResponse)
                    .collect(Collectors.toList());

            // Return the list of PostResponse
            return ResponseEntity.ok(reverseList(postResponses));
        } catch (Exception e) {
            return ResponseEntity.badRequest().body(null);
        }
    }


    @Override
    public ResponseEntity<?> likePost(String postId) {
        try {
            String userId = commonUtils.getUserId().toString();
            Post post = postRepository.findById(postId).orElse(null);
            if (post == null) {
                return ResponseEntity.badRequest().body("Post not found");
            }
            if (post.getLikes().contains(userId)) {
                post.getLikes().remove(userId);
            } else {
                post.getLikes().add(userId);
            }
            UserResponse profile = profileService.getUserById(userId).getBody();
            String titleAndMessage = "Post liked: Your post has been liked by " + profile.getFirstName();
            notificationService.sendNotification(post.getAuthorId(), titleAndMessage);
            postRepository.save(post);
            return ResponseEntity.ok("Post liked successfully");
        } catch (Exception e) {
            return ResponseEntity.badRequest().body("Error liking post");
        }
    }

    @Override
    public List<PostResponse> searchPosts(String query) {
        try {
            List<Post> posts = postRepository.findAll();
            return posts.stream()
                    .filter(post -> post.getContent().contains(query) || post.getTopic().contains(query))
                    .map(this::getPostResponse)
                    .collect(Collectors.toList());
        } catch (Exception e) {
            throw new RuntimeException("Error searching posts");
        }
    }

    @Override
    public ResponseEntity<?> commentOnPost(String postId, Comment comment) {
        try {
            if (comment.getUserId() == null) {
                comment.setUserId(commonUtils.getUserId().toString());
            }
            comment.setCreatedAt(new Date());
            Comment _comment = commentRepository.save(comment);
            Post post = postRepository.findById(postId).orElse(null);
            if (post == null) {
                return ResponseEntity.badRequest().body("Post not found");
            }
            post.getComments().add(_comment.getId());
            UserResponse response = profileService.getUserById(commonUtils.getUserId().toString()).getBody();
            String message = response.getFirstName() + "commented on your post";
            notificationService.sendNotification(post.getAuthorId(), message);
            postRepository.save(post);
            return ResponseEntity.ok("Comment added successfully");
        } catch (Exception e) {
            return ResponseEntity.badRequest().body("Error adding comment");
        }
    }

    private PostResponse getPostResponse(Post post) {
        PostResponse postResponse = new PostResponse();
        postResponse.setId(post.getId());
        postResponse.setUser(getUserResponseMap(post));
        postResponse.setLiked(post.getLikes().contains(commonUtils.getUserId().toString()));
        postResponse.setGroup(getGroupMap(post));
        postResponse.setContent(post.getContent());
        postResponse.setTopic(post.getTopic());
        postResponse.setLikes(post.getLikes());
        postResponse.setComments(reverseList(getCommentsList(post)));
        postResponse.setImages(post.getImages());
        if (post.getPoll() != null) {
            postResponse.setPoll(pollSevice.getPollById(post.getPoll()));
        }
        postResponse.setAttachments(getAttachmentsList(post));
        postResponse.setVisibility(post.getVisibility());
        postResponse.setCreatedAt(post.getCreatedAt());
        postResponse.setUpdatedAt(post.getUpdatedAt());
        postResponse.setTimestamp(post.getCreatedAt());
        postResponse.setEdit(checkLoggedInUser(post.getAuthorId()));
        return postResponse;
    }

    private HashMap<String, String> getUserResponseMap(Post post) {
        UserResponse userResponse = profileService.getUserById(post.getAuthorId()).getBody();
        HashMap<String, String> user = new HashMap<>();
        assert userResponse != null;
        user.put("id", userResponse.getUserId());
        user.put("name", userResponse.getFirstName());
        user.put("profilePic", userResponse.getProfilePicture());
        user.put("userName", userResponse.getFirstName() + " " + userResponse.getLastName());
        return user;
    }

    private HashMap<String, String> getGroupMap(Post post) {
        if (post.getGroupId() != null) {
            Group group = groupRepository.findById(post.getGroupId()).orElse(null);
            HashMap<String, String> groupMap = new HashMap<>();
            groupMap.put("id", group.getId());
            groupMap.put("name", group.getName());
            return groupMap;
        }
        return null;
    }

    private List<Comment> getCommentsList(Post post) {
        List<Comment> comments = commentRepository.findAllById(post.getComments());
        return comments.stream().map(comment -> {
            HashMap<String, String> userMap = new HashMap<>();
            UserResponse _userResponse = profileService.getUserById(comment.getUserId()).getBody();
            assert _userResponse != null;
            comment.setProfilePic(_userResponse.getProfilePicture());
            comment.setUsername(_userResponse.getFirstName() + " " + _userResponse.getLastName());
            return comment;
        }).collect(Collectors.toList());
    }

    private List<HashMap<String, String>> getAttachmentsList(Post post) {
        List<HashMap<String, String>> attachments = null;
        if (post.getAttachments() != null && !post.getAttachments().isEmpty()) {
            List<File> files = fileRepository.findAllById(post.getAttachments());
            for (File file : files) {
                HashMap<String, String> attachment = new HashMap<>();
                attachment.put("id", file.getId());
                attachment.put("name", file.getFilename());
                attachments.add(attachment);
            }
        }
        return attachments;
    }

    private boolean checkLoggedInUser(String userId) {
        return commonUtils.getUserId().toString().equals(userId);
    }


    public <T> List<T> reverseList(List<T> list) {
        List<T> reversedList = new ArrayList<>(list);
        Collections.reverse(reversedList);
        return reversedList;
    }

//    private PostResponse getPostResponse(Post post) {
//        PostResponse postResponse = new PostResponse();
//        postResponse.setId(post.getId());
//        UserResponse userResponse = profileService.getUserById(post.getAuthorId()).getBody();
//        HashMap<String, String> user = new HashMap<>();
//        assert userResponse != null;
//        user.put("id", userResponse.getUserId());
//        user.put("name", userResponse.getFirstName());
//        user.put("profilePic", userResponse.getProfilePicture());
//        user.put("userName", userResponse.getFirstName() + " " + userResponse.getLastName());
//
//        postResponse.setUser(user);
//
//        if(post.getLikes().contains(commonUtils.getUserId().toString())) {
//            postResponse.setLiked(true);
//        }
//
//        if(post.getGroupId()!=null){
//            Group group = groupRepository.findById(post.getGroupId()).orElse(null);
//            HashMap<String, String> groupMap = new HashMap<>();
//            groupMap.put("id", group.getId());
//            groupMap.put("name", group.getName());
//            postResponse.setGroup(groupMap);
//        }
//
//
//        postResponse.setContent(post.getContent());
//        postResponse.setTopic(post.getTopic());
//        postResponse.setLikes(post.getLikes());
//
//
//        List<Comment> comments = commentRepository.findAllById(post.getComments());
//        comments= comments.stream().map(comment -> {
//            HashMap<String, String> userMap = new HashMap<>();
//
//            UserResponse _userResponse = profileService.getUserById(comment.getUserId()).getBody();
//            assert _userResponse != null;
//            comment.setProfilePic(_userResponse.getProfilePicture());
//            comment.setUsername(_userResponse.getFirstName() + " " + _userResponse.getLastName());
//            return comment;
//        }).collect(Collectors.toList());
//
//        postResponse.setComments(comments);
//
//        postResponse.setImages(post.getImages());
//
//        if(post.getPoll()!=null){
//
//            postResponse.setPoll(pollSevice.getPollById(post.getPoll()));
//        }
//
//        List<HashMap<String, String>> attachments = null;
//
//        if (post.getAttachments() != null && !post.getAttachments().isEmpty()) {
//            List<File> files = fileRepository.findAllById(post.getAttachments());
//            for (File file : files) {
//                HashMap<String, String> attachment = new HashMap<>();
//                attachment.put("id", file.getId());
//                attachment.put("name", file.getFilename());
//                attachments.add(attachment);
//
//            }
//            postResponse.setAttachments(attachments);
//
//            postResponse.setVisibility(post.getVisibility());
//            postResponse.setCreatedAt(post.getCreatedAt());
//            postResponse.setUpdatedAt(post.getUpdatedAt());
//            postResponse.setTimestamp(post.getCreatedAt());
//
//        }
//        return postResponse;
//    }


}
