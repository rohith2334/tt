package com.app.universityblog.main.service;

import com.app.universityblog.common.models.Admin;
import com.app.universityblog.common.payload.request.SignupRequest;
import com.app.universityblog.common.repository.AdminRepository;
import com.app.universityblog.common.utils.CommonUtils;
import com.app.universityblog.main.models.Profile;
import com.app.universityblog.main.models.Invitation;
import com.app.universityblog.main.payload.response.UserResponse;
import com.app.universityblog.main.repository.ProfileRepository;
import com.app.universityblog.main.repository.InvitationRepository;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;

import java.util.HashMap;
import java.util.List;

@Service
public class ProfileServiceImpl implements ProfileService{

    private final ProfileRepository profileRepository;

    private final AdminRepository adminRepository;

    private final InvitationRepository invitationRepository;

    private final FileService fileService;

    private final UserService userService;

    private final CommonUtils commonUtils;

    private final NotificationService notificationService;

    public ProfileServiceImpl(ProfileRepository profileRepository, UserService userService, InvitationRepository requestRepository, CommonUtils commonUtils, AdminRepository   adminRepository, FileService fileService, NotificationService notificationService) {
        this.profileRepository= profileRepository;
        this.fileService = fileService;
        this.adminRepository=adminRepository;
        this.commonUtils=commonUtils;
        this.invitationRepository =requestRepository;
        this.userService=userService;
        this.notificationService = notificationService;
    }

    @Override
    public String createProfile(SignupRequest signupRequest,Boolean isAdmin) {
        try{
            if(isAdmin){
                Admin admin = Admin.builder()
                        .userId(signupRequest.getUserId())
                        .username(signupRequest.getUsername())
                        .email(signupRequest.getEmail())
                        .password(signupRequest.getPassword())
                        .profileImage(fileService.saveImage(signupRequest.getProfileImage()))
                        .createdAt(String.valueOf(System.currentTimeMillis()))
                        .updatedAt(String.valueOf(System.currentTimeMillis()))
                        .build();
                Admin _admin = adminRepository.save(admin);
                return _admin.getId();
            }
            Profile profile = Profile.builder()
                    .userId(signupRequest.getUserId())
                    .userName(signupRequest.getUsername())
                    .email(signupRequest.getEmail())
                    .firstName(signupRequest.getFirstName())
                    .lastName(signupRequest.getLastName())
                    .profilePicture(fileService.saveImage(signupRequest.getProfileImage()))
                    .phoneNumber(signupRequest.getPhoneNumber())
                    .active("true")
                    .createdAt(String.valueOf(System.currentTimeMillis()))
                    .updatedAt(String.valueOf(System.currentTimeMillis()))
                    .savedPosts(List.of())
                    .friendsList(List.of())
                    .groups(List.of())
                    .socials(new HashMap<>())
                    .build();
            Profile _profile = profileRepository.save(profile);
            return _profile.getId();
        } catch (Exception e) {
            e.printStackTrace();
            return "Error creating profile";
        }
    }

    @Override
    public ResponseEntity<UserResponse> getUserById(String userId) {
        try{
            Profile profile = profileRepository.findByUserId(userId);
            if (profile == null) {
                return ResponseEntity.notFound().build();
            }
            return ResponseEntity.ok(UserResponse.builder()
                    .userId(profile.getUserId())
                    .userName(profile.getUserName())
                    .email(profile.getEmail())
                    .firstName(profile.getFirstName())
                    .lastName(profile.getLastName())
                    .profilePicture(profile.getProfilePicture())
                    .phoneNumber(profile.getPhoneNumber())
                    .active(profile.getActive())
                    .createdAt(profile.getCreatedAt())
                    .updatedAt(profile.getUpdatedAt())
                    .savedPosts(profile.getSavedPosts())
                    .friendsList(profile.getFriendsList())
                    .bannedUsers(profile.getBannedUsers())
                    .groups(profile.getGroups())
                    .socials(profile.getSocials())
                    .build());
        } catch (Exception e) {
            return ResponseEntity.notFound().build();
        }
    }

    @Override
    public ResponseEntity<List<UserResponse>> getFriends() {
        try {
            Profile profile = profileRepository.findByUserId(commonUtils.getUserId().toString());
            List<UserResponse> userResponses = profile.getFriendsList().stream().map(friendId -> {
                Profile friendProfile = profileRepository.findByUserId(friendId);
                return UserResponse.builder()
                        .userId(friendProfile.getUserId())
                        .userName(friendProfile.getUserName())
                        .email(friendProfile.getEmail())
                        .firstName(friendProfile.getFirstName())
                        .lastName(friendProfile.getLastName())
                        .profilePicture(friendProfile.getProfilePicture())
                        .build();
            }).toList();
            return ResponseEntity.ok(userResponses);
        } catch (Exception e) {
            return ResponseEntity.notFound().build();
        }
    }

    @Override
    public ResponseEntity<List<UserResponse>> getFriendRequests() {
        try {
            List<Invitation> requests = invitationRepository.findByReceiverId(commonUtils.getUserId().toString());
            List<UserResponse> userResponses = requests.stream().map(request -> {
                Profile profile = profileRepository.findByUserId(request.getSenderId());
                return UserResponse.builder()
                        .userId(profile.getUserId())
                        .userName(profile.getUserName())
                        .email(profile.getEmail())
                        .firstName(profile.getFirstName())
                        .lastName(profile.getLastName())
                        .profilePicture(profile.getProfilePicture())
                        .build();
            }).toList();
            return ResponseEntity.ok(userResponses);
        } catch (Exception e) {
            return ResponseEntity.notFound().build();
        }
    }

    @Override
    public ResponseEntity<?> sendFriendRequest(String friendId) {

        try{

            Profile _profile = profileRepository.findByUserId(friendId);
            if(_profile.getFriendsList().contains(friendId)){
                return ResponseEntity.badRequest().build();
            }
            if(_profile.getBannedUsers()!=null && _profile.getBannedUsers().contains(commonUtils.getUserId().toString())){
                return ResponseEntity.noContent().build();
            }

            Invitation requests= new Invitation();
            requests.setSenderId(commonUtils.getUserId().toString());
            requests.setReceiverId(friendId);
            Profile profile = profileRepository.findByUserId(commonUtils.getUserId().toString());


            notificationService.sendNotification(friendId,"Friend Request from "+profile.getUserName());
            invitationRepository.save(requests);
            return ResponseEntity.ok().build();
        }catch (Exception e){
            return ResponseEntity.notFound().build();
        }
    }

    @Override
    public ResponseEntity<?> respondFriendRequest(String friendId, String response) {
        try{
            Invitation requests = invitationRepository.findBySenderIdAndReceiverId(friendId,commonUtils.getUserId().toString()).get(0);
            if(requests==null){
                return ResponseEntity.notFound().build();
            }
            if(response.equals("accept")){
                Profile profile= profileRepository.findByUserId(commonUtils.getUserId().toString());
                Profile friendProfile = profileRepository.findByUserId(friendId);

                profile.getFriendsList().add(friendId);
                friendProfile.getFriendsList().add(commonUtils.getUserId().toString());

                String message ="Friend Request Accepted : "+ profile.getUserName() +" accepted your friend request";
                notificationService.sendNotification(friendId,message);

                profileRepository.save(profile);
                profileRepository.save(friendProfile);

                invitationRepository.delete(requests);
                return ResponseEntity.ok().build();
            }
            notificationService.sendNotification(friendId,"Friend Request Rejected "+commonUtils.getUserId().toString());
            invitationRepository.delete(requests);
            return ResponseEntity.ok().build();

        }catch (Exception e){
            return ResponseEntity.notFound().build();
        }
    }

    @Override
    public ResponseEntity<List<String>> getSentRequests() {
        try{
            List<Invitation> requests = invitationRepository.findBySenderId(commonUtils.getUserId().toString());
            List<String> sentRequests = requests.stream().map(Invitation::getReceiverId).toList();
            if(sentRequests.isEmpty()){
                return ResponseEntity.ok(List.of());
            }
            return ResponseEntity.ok(sentRequests);
        }catch (Exception e){
            throw new RuntimeException();
        }
    }

    @Override
    public ResponseEntity<?> deleteFriendRequest(String friendId) {
        try{
            Invitation requests = invitationRepository.findBySenderIdAndReceiverId(commonUtils.getUserId().toString(),friendId).get(0);
            if(requests==null){
                return ResponseEntity.notFound().build();
            }
            invitationRepository.delete(requests);
            return ResponseEntity.ok().build();
        }catch (Exception e){
            return ResponseEntity.notFound().build();
        }
    }

    @Override
    public ResponseEntity<?> unFriend(String friendId) {
        try{
            Profile profile= profileRepository.findByUserId(commonUtils.getUserId().toString());
            Profile friendProfile = profileRepository.findByUserId(friendId);

            profile.getFriendsList().remove(friendId);
            friendProfile.getFriendsList().remove(commonUtils.getUserId().toString());
            notificationService.sendNotification(friendId,"Unfriended by "+commonUtils.getUserId().toString());
            profileRepository.save(profile);
            profileRepository.save(friendProfile);

            return ResponseEntity.ok().build();
        }catch (Exception e){
            return ResponseEntity.notFound().build();
        }
    }

    @Override
    public ResponseEntity<?> getFriendSuggestion() {
        try{
            String userId = commonUtils.getUserId().toString();
            Profile profile = profileRepository.findByUserId(userId);
            List<String> friends = profile.getFriendsList();
            List<String> banned = profile.getBannedUsers();
           List<String> allUsers= userService.getAllUserIds();
           List<Invitation> requests = invitationRepository.findBySenderId(userId);
            List<UserResponse> userResponses = allUsers.stream()
                    .filter(user->{
                        if(user.equals(userId)){
                            return false;
                        }
                        if(friends.contains(user)){
                            return false;
                        }
                        if (banned!=null && banned.contains(user)){
                            return false;
                        }
                        for(Invitation request:requests){
                            if(request.getReceiverId().equals(user)){
                                return false;
                            }
                        }
                        return true;
                    })
                    .map(friendId -> {
                Profile friendProfile = profileRepository.findByUserId(friendId);
                return UserResponse.builder()
                        .userId(friendProfile.getUserId())
                        .userName(friendProfile.getUserName())
                        .email(friendProfile.getEmail())
                        .firstName(friendProfile.getFirstName())
                        .lastName(friendProfile.getLastName())
                        .profilePicture(friendProfile.getProfilePicture())
                        .build();
            }).toList();
            return ResponseEntity.ok(userResponses);
        }catch (Exception e){
            return ResponseEntity.notFound().build();
        }
    }

    @Override
    public List<UserResponse> searchUsers(String query) {
        try{
            List<Profile> profiles = profileRepository.findAll();
            return profiles.stream()
                    .filter(profile -> profile.getUserName().contains(query) || profile.getFirstName().contains(query) || profile.getLastName().contains(query))
                    .map(profile -> UserResponse.builder()
                            .userId(profile.getUserId())
                            .userName(profile.getUserName())
                            .email(profile.getEmail())
                            .firstName(profile.getFirstName())
                            .lastName(profile.getLastName())
                            .profilePicture(profile.getProfilePicture())
                            .build())
                    .toList();
        }
        catch (Exception e){
           throw new RuntimeException("Error searching users");
        }
    }

    @Override
    public ResponseEntity<?> block(String friendId) {
        try{
            Profile profile= profileRepository.findByUserId(commonUtils.getUserId().toString());
            Profile friendProfile = profileRepository.findByUserId(friendId);

            profile.getFriendsList().remove(friendId);
            friendProfile.getFriendsList().remove(commonUtils.getUserId().toString());
            if(profile.getBannedUsers()==null){
                profile.setBannedUsers(List.of(friendId));
            }else{
                profile.getBannedUsers().add(friendId);
            }
            profileRepository.save(profile);
            profileRepository.save(friendProfile);

            return ResponseEntity.ok().build();
        }catch (Exception e){
            return ResponseEntity.notFound().build();
        }
    }
}
