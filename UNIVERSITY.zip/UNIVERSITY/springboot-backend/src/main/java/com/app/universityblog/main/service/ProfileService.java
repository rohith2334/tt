package com.app.universityblog.main.service;

import com.app.universityblog.common.payload.request.SignupRequest;
import com.app.universityblog.main.models.Profile;
import com.app.universityblog.main.payload.response.UserResponse;
import org.springframework.http.ResponseEntity;

import java.util.List;

public interface ProfileService {
    String createProfile(SignupRequest signupRequest,Boolean isAdmin);

    ResponseEntity<UserResponse> getUserById(String userId);
    ResponseEntity<List<UserResponse>> getFriends();

    ResponseEntity<List<UserResponse>> getFriendRequests();

    ResponseEntity<?> sendFriendRequest(String friendId);

    ResponseEntity<?> respondFriendRequest(String friendId, String response);

    ResponseEntity<List<String>> getSentRequests();

    ResponseEntity<?> deleteFriendRequest(String friendId);

    ResponseEntity<?>  unFriend(String friendId);

    ResponseEntity<?>  getFriendSuggestion ();

    List<UserResponse> searchUsers(String query);

    ResponseEntity<?> block(String friendId);
}
