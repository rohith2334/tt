package com.app.universityblog.main.payload.response;

import com.app.universityblog.main.models.Comment;
import com.app.universityblog.main.models.Poll;
import com.app.universityblog.main.models.VisibilityStatus;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

@AllArgsConstructor
@NoArgsConstructor
@Data
public class PostResponse {
    private String id;
    private HashMap<String,String> user;
    private HashMap<String,String>  group;
    private String content;
    private String topic;
    private List<String> likes;
    private List<Comment> comments;
    private List<String> images;
    private Poll poll;
    private boolean liked;
    private List<HashMap<String,String>> attachments;
//    private List<String> tags;
    private VisibilityStatus visibility;
    private Date createdAt;
    private Date updatedAt;
    private Date timestamp;
    private boolean isEdit;

//    private String commentFilter;
}
