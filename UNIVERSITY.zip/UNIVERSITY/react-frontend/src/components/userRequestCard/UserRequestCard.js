import React from "react";
import "./UserRequestCard.css";
import UserService from "../../services/UserService";
export default function UserRequestCard({ profile, onAcceptOrReject }) {
  console.log(profile);
  const handleClick = (id, action) => {
    console.log(id, action);
    onAcceptOrReject(id);
    UserService.respondToFriendRequest(id, action)
      .then((response) => {
        console.log(response.data);
      })
      .catch((error) => {
        console.log(error);
      });
  };
  return (
    <div className="user">
      <div className="userInfo">
        <img
          src={`http://localhost:8080/api/v1/image/${
            profile && profile.profilePicture
          }`}
          alt=""
        />
        <span>{profile && profile.firstName + " " + profile.lastName}</span>
      </div>
      <div className="buttons">
        <button onClick={() => handleClick(profile.userId, "accept")}>
          Accept
        </button>
        <button onClick={() => handleClick(profile.userId, "reject")}>
          Reject
        </button>
      </div>
    </div>
  );
}
