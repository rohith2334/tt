import React from "react";
import "./UserRequestCard.css";
import UserService from "../../services/UserService";

export default function UserSuggestionCard({ profile, onFollow }) {
  // console.log(profile);
  const handleClick = (id) => {
    onFollow(id);
    console.log(id);
    UserService.sendFriendRequest(id)
      .then((response) => {
        console.log(response.data);
      })
      .catch((error) => {
        console.log(error);
      });
  };
  return (
    <div className="user">
      <div className="userInfo">
        <img
          src={`http://localhost:8080/api/v1/image/${
            profile && profile.profilePicture
          }`}
          alt=""
        />
        <span>{profile && profile.firstName + " " + profile.lastName}</span>
      </div>
      <div className="buttons">
        <button onClick={() => handleClick(profile.userId)}>Follow</button>
      </div>
    </div>
  );
}
