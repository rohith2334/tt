import React, { useState, useEffect } from "react";
import Button from "@mui/material/Button";
import Card from "@mui/material/Card";
import CardContent from "@mui/material/CardContent";
import Typography from "@mui/material/Typography";
import Avatar from "@mui/material/Avatar";
import UserService from "../services/UserService";
import { WindowSharp } from "@mui/icons-material";

function AdminPage() {
  const [view, setView] = useState("overview");
  const [users, setUsers] = useState([]);
  const [groups, setGroups] = useState([]);
  const [posts, setPosts] = useState([]);
  const [nonVerifiedUsers, setNonVerifiedUsers] = useState([]);
  const [nonVerifiedGroups, setNonVerifiedGroups] = useState([]);

  const handleLogout = () => {
    localStorage.removeItem("user");
    localStorage.removeItem("jwtToken");
    window.location.href = "/login";
  }

  useEffect(() => {
    UserService.getUsers()
      .then((response) => {
        setUsers(response.data);
      })
      .catch((error) => {
        console.error("There was an error!", error);
      });

    UserService.getAllGroups()
      .then((response) => {
        setGroups(response.data);
      })
      .catch((error) => {
        console.error("There was an error!", error);
      });

    UserService.getPosts()
      .then((response) => {
        setPosts(response.data);
      })
      .catch((error) => {
        console.error("There was an error!", error);
      });
  }, []);

  useEffect(() => {
    if (view === "users") {
      UserService.getNonVerifiedUsers()
        .then((response) => {
          setNonVerifiedUsers(response.data);
        })
        .catch((error) => {
          console.error("There was an error!", error);
        });
    }
  }, [view]);

  useEffect(() => {
    if (view === "groups") {
      UserService.getNonVerifiedGroups()
        .then((response) => {
          setNonVerifiedGroups(response.data);
        })
        .catch((error) => {
          console.error("There was an error!", error);
        });
    }
  }, [view]);

  const handleVerifyGroup = (groupId) => {
    UserService.verifyGroup(groupId)
      .then((response) => {
        setNonVerifiedGroups(
          nonVerifiedGroups.filter((group) => group.groupId !== groupId)
        );
      })
      .catch((error) => {
        console.error("There was an error!", error);
      });
  };

  const handleVerifyUser = (userId) => {
    UserService.verifyUser(userId)
      .then((response) => {
        setNonVerifiedUsers(
          nonVerifiedUsers.filter((user) => user.userId !== userId)
        );
      })
      .catch((error) => {
        console.error("There was an error!", error);
      });
  };

  return (
    <div sx={{ marginLeft: 200 }}>
      <div>
        <Typography sx={{ marginLeft: 70 }} variant="h3">
          ADMIN PAGE
        </Typography>
        <Button
          sx={{ marginLeft: 60 }}
          variant="contained"
          color="primary"
          onClick={() => setView("overview")}
        >
          Overview
        </Button>
        <Button
          sx={{ marginLeft: 10 }}
          variant="contained"
          color="secondary"
          onClick={() => setView("users")}
        >
          Users
        </Button>
        <Button
          sx={{ margin: 10 }}
          variant="contained"
          color="success"
          onClick={() => setView("groups")}
        >
          Groups
        </Button>
        <Button
          sx={{ margin: 10 }}
          variant="outlined"
          onClick={handleLogout}
        >
          Logout
        </Button>
      </div>

      {view === "overview" && (
        <div sx={{ display: "flex", justifyContent: "center", gap: 5 }}>
          <Card
            sx={{
              width: "30%",
              marginBottom:"30px",
              marginLeft: "480px",
              height: "100px",
              textAlign: "center",
              gap: 5,
            }}
          >
            <CardContent>
              <Typography>Total Users: {users.length}</Typography>
            </CardContent>
          </Card>
          <Card
            sx={{
              width: "30%",
              marginBottom:"30px",
              marginLeft: "480px",
              height: "100px",
              textAlign: "center",
            }}
          >
            <CardContent>
              <Typography>Total Groups: {groups.length}</Typography>
            </CardContent>
          </Card>
          <Card
            sx={{
              width: "30%",
              marginBottom:"30px",
              height: "100px",
              marginLeft: "480px",
              textAlign: "center",
            }}
          >
            <CardContent>
              <Typography>Total Posts: {posts.length}</Typography>
            </CardContent>
          </Card>
        </div>
      )}

      {view === "users" &&
        nonVerifiedUsers.map((user) => (
          <Card key={user.id}  sx={{
            width: "30%",
            marginBottom:"30px",
            marginLeft: "480px",
            height: "200px",
            textAlign: "center",
            gap: 5,
          }}>
            <CardContent>
              <Avatar alt={user.userName} src={`http://localhost:8080/api/v1/image/${user.profilePicture}`} />
              <Typography>{user.userName}</Typography>
              <Button
                variant="contained"
                color="primary"
                onClick={() => handleVerifyUser(user.userId)}
              >
                Verify
              </Button>
            </CardContent>
          </Card>
        ))}

      {view === "groups" &&     
        nonVerifiedGroups.map((group) => (
          <Card key={group.id}
          sx={{
            width: "30%",
            marginBottom:"30px",
            marginLeft: "480px",
            height: "200px",
            textAlign: "center",
            gap: 5,
          }}>
            <CardContent>
              <Avatar alt={group.name} src={`http://localhost:8080/api/v1/image/${group.profileImage}`} />
              <Typography>{group.name}</Typography>
              <Button
                variant="contained"
                color="primary"
                onClick={() => handleVerifyGroup(group.groupId)}
              >
                Verify
              </Button>
            </CardContent>
          </Card>
        ))}
    </div>
  );
}

export default AdminPage;
