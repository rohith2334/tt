import "./navbar.css";
import DarkModeOutlinedIcon from "@mui/icons-material/DarkModeOutlined";
import WbSunnyOutlinedIcon from "@mui/icons-material/WbSunnyOutlined";
import NotificationsIcon from "@mui/icons-material/Notifications";
import { Link } from "react-router-dom";
import { useContext, useEffect } from "react";
import { DarkModeContext } from "../../context/darkModeContext";
import UserService from "../../services/UserService";
import { useState } from "react";
import DoneIcon from "@mui/icons-material/Done";
import MenuList from '@mui/material/MenuList';

import {
  Modal,
  ListItemText,
  IconButton,
  Menu,
  MenuItem,
  Badge,
  ListItemIcon,
  Box,
  TextField,
  Button,
  Select,
  FormControl,
  InputLabel,
  Typography,
} from "@mui/material";
import Chip from "@mui/material/Chip";

import { Input } from "@mui/material";

const Navbar = () => {
  const { toggle, darkMode } = useContext(DarkModeContext);
  const [userDetails, setUserDetails] = useState({});
  const currentUser = localStorage.getItem("user")
    ? JSON.parse(localStorage.getItem("user"))
    : {};
  const userId = currentUser.id;
  const [modalOpen, setModalOpen] = useState(false);
  const [modal2Open, setModal2Open] = useState(false);
  const [postText, setPostText] = useState("");
  const [optionInput, setOptionInput] = useState("");
  const [notifications, setNotifications] = useState([]);
  const [anchorElNotifications, setAnchorElNotifications] = useState(null);
  const [postRequest, setPostRequest] = useState({
    groupId: "",
    content: "",
    attachments: [],
    images: [],
    visibilityStatus: "",
    poll: { question: "", option: [] },
  });
  const [groupRequest, setGroupRequest] = useState({
    name: "",
    description: "",
    visibilityStatus: "GROUP",
    profileImage: "",
    coverImage: "",
  });
  const [selectedGroup, setSelectedGroup] = useState("");
  const [groups, setGroups] = useState([]);

  useEffect(() => {
    UserService.getNotifications()
      .then((response) => {
        setNotifications(response.data);
      })
      .catch((error) => {
        console.error("There was an error!", error);
      });
  }, []);

  const handleTick = (notificationId) => {
    UserService.updateNotification(notificationId)
      .then((response) => {
        setNotifications(
          notifications.filter(
            (notification) => notification.id !== notificationId
          )
        );
      })
      .catch((error) => {
        console.error("There was an error!", error);
      });
  };

  useEffect(() => {
    UserService.getGroups()
      .then((response) => {
        setGroups(response.data);
      })
      .catch((error) => {});
    UserService.getUserById(userId)
      .then((response) => {
        setUserDetails(response.data);
      })
      .catch((error) => {
        console.error("Failed to get user details:", error);
      });
  }, []);

  const handleClickNotifications = (event) => {
    setAnchorElNotifications(event.currentTarget);
  };

  const handleCloseNotifications = () => {
    setAnchorElNotifications(null);
  };

  const handleCreatePost = () => {
    setModalOpen(false);
    UserService.createPost(postRequest)
      .then((response) => {
        console.log("Post created successfully", response.data);
        alert("Post created successfully");
        window.location.reload();
      })
      .catch((error) => {
        console.error("Failed to create post:", error);
      });
    setModalOpen(true);
  };

  const handlePostTextChange = (event) => {
    setPostText(event.target.value);
    setPostRequest((prev) => ({ ...prev, content: event.target.value }));
  };

  const handleGroupChange = (event) => {
    setSelectedGroup(event.target.value);
    console.log("Selected", event.target.value);
    setPostRequest((prev) => ({ ...prev, groupId: event.target.value }));
    if (event.target.value === "PUBLIC") {
      setPostRequest((prev) => ({ ...prev, visibilityStatus: "PUBLIC" }));
    } else if (event.target.value === "FRIENDS") {
      setPostRequest((prev) => ({ ...prev, visibilityStatus: "FRIENDS" }));
    } else {
      setPostRequest((prev) => ({ ...prev, visibilityStatus: "GROUP" }));
    }
  };

  const handleNameChange = (event) => {
    setGroupRequest((prev) => ({ ...prev, name: event.target.value }));
  };

  const handleDescriptionChange = (event) => {
    setGroupRequest((prev) => ({ ...prev, description: event.target.value }));
  };

  const handleCreateGroup = () => {
    setModal2Open(false);
    UserService.createGroup(groupRequest)
      .then((response) => {
        console.log("Group created successfully", response.data);
        alert("Group created successfully");
        window.location.reload();
      })
      .catch((error) => {
        console.error("Failed to create group:", error);
        alert("Failed to create group");
      });

    setModal2Open(true);
  };

  const handleImageChange = async (event) => {
    const file = event.target.files[0];
    let reader = new FileReader();

    reader.onloadend = () => {
      const base64Image = reader.result;
      UserService.uploadImage(base64Image)
        .then((response) => {
          setPostRequest((prev) => ({
            ...prev,
            images: [...prev.images, response.data],
          }));
        })
        .catch((error) => {
          console.error("Failed to upload image:", error);
        });
    };
    reader.readAsDataURL(file);
  };

  const handleCreatePostButton = (event) => {
    event.stopPropagation();
    setModalOpen(true);
  };

  const handleCreateGroupButton = (event) => {
    event.stopPropagation();
    setModal2Open(true);
  };

  const handleProfileImageChange = async (event) => {
    const file = event.target.files[0];
    let reader = new FileReader();

    reader.onloadend = () => {
      const base64Image = reader.result;
      UserService.uploadImage(base64Image)
        .then((response) => {
          setGroupRequest((prev) => ({
            ...prev,
            profileImage: response.data,
          }));
        })
        .catch((error) => {
          console.error("Failed to upload image:", error);
        });
    };
    reader.readAsDataURL(file);
  };

  const handleQuestionChange = (event) => {
    setPostRequest({
      ...postRequest,
      poll: {
        ...postRequest.poll,
        question: event.target.value,
      },
    });
  };

  const handleOptionInputChange = (event) => {
    setOptionInput(event.target.value);
    console.log("Option Input", event.target.value);
  };

  const handleOptionInputKeyDown = (event) => {
    if (event.key === "Enter") {
      event.preventDefault();
      setPostRequest({
        ...postRequest,
        poll: {
          ...postRequest.poll,
          option: [...postRequest.poll.option, optionInput],
        },
      });
      console.log("Post Request", postRequest);
      setOptionInput("");
    }
  };

  const handleDeleteOption = (optionToDelete) => () => {
    setPostRequest({
      ...postRequest,
      poll: {
        ...postRequest.poll,
        option: postRequest.poll.option.filter(
          (option) => option !== optionToDelete
        ),
      },
    });
  };

  useEffect(() => {
    console.log("Post Request", postRequest);
  }, [postRequest]);

  const handleCoverImageChange = async (event) => {
    const file = event.target.files[0];
    let reader = new FileReader();

    reader.onloadend = () => {
      const base64Image = reader.result;
      UserService.uploadImage(base64Image)
        .then((response) => {
          setGroupRequest((prev) => ({
            ...prev,
            coverImage: response.data,
          }));
        })
        .catch((error) => {
          console.error("Failed to upload image:", error);
        });
    };
    reader.readAsDataURL(file);
  };

  return (
    <div className="navbar">
      <div className="left">
        <Link to="/" style={{ textDecoration: "none" }}>
          <span>UNIVERSITY BLOG</span>
        </Link>
      </div>
      <div className="createPost">
        <button
          style={{
            backgroundColor: "#3bb19b",
            color: "white",
            padding: "10px 20px",
            borderRadius: "5px",
            border: "none",
            cursor: "pointer",
            fontWeight: "bold",
          }}
          onClick={handleCreatePostButton}
        >
          CREATE POST
        </button>
      </div>
      <div className="createGroup">
        <button
          style={{
            backgroundColor: "#938eef",
            color: "white",
            padding: "10px 20px",
            borderRadius: "5px",
            border: "none",
            cursor: "pointer",
            fontWeight: "bold",
          }}
          onClick={handleCreateGroupButton}
        >
          CREATE GROUP
        </button>
      </div>
      <div className="right">
        <IconButton
          color="inherit"
          onClick={handleClickNotifications}
          style={{ marginLeft: "20px" }}
        >
          <Badge badgeContent={notifications.length} color="error">
            <NotificationsIcon />
          </Badge>
        </IconButton>
        <Menu
          anchorEl={anchorElNotifications}
          open={Boolean(anchorElNotifications)}
          onClose={handleCloseNotifications}
          >
          <MenuList style={{ maxHeight: '20ch', overflowY: 'scroll' }}>

        
          {notifications.length === 0 ? (
            <MenuItem>No new notifications</MenuItem>
          ) : (
            notifications.map((notification) => (
              <MenuItem key={notification.id}>
                <ListItemIcon>
                  <DoneIcon onClick={() => handleTick(notification.id)} />
                </ListItemIcon>
                <ListItemText primary={notification.message} />
              </MenuItem>
            ))
          )}
          </MenuList>
        </Menu>
        <div className="user">
          <img
            src={`http://localhost:8080/api/v1/image/${
              userDetails && userDetails.profilePicture
            }`}
            alt=""
          />
          <span>{userDetails.userName}</span>
        </div>
        <Modal
          style={{ marginTop: "40px", marginLeft: "500px" }}
          open={modalOpen}
          onClose={() => setModalOpen(false)}
          aria-labelledby="modal-modal-title"
          aria-describedby="modal-modal-description"
        >
          <Box sx={{ width: 400, padding: 2, bgcolor: "background.paper" }}>
            <TextField
              id="outlined-multiline-static"
              label="Message"
              multiline
              rows={4}
              value={postText}
              onChange={handlePostTextChange}
              fullWidth
            />
            <br></br>
            <br></br>
            <FormControl fullWidth>
              <InputLabel id="group-select-label">Group</InputLabel>
              <Select
                labelId="group-select-label"
                id="group-select"
                value={selectedGroup}
                label="Group"
                onChange={handleGroupChange}
              >
                {groups &&
                  groups.map((group, index) => (
                    <MenuItem key={index} value={group.groupId}>
                      {group.name}
                    </MenuItem>
                  ))}
                <MenuItem value="PUBLIC">Public</MenuItem>
                <MenuItem value="FRIENDS">Friends</MenuItem>
              </Select>
            </FormControl>
            <br></br>
            <label htmlFor="contained-button-file">
              <br></br>
              <Typography variant="caption">Upload Image</Typography>
              <br></br>
              <Input
                accept="image/*"
                id="contained-button-image"
                multiple
                type="file"
                onChange={handleImageChange}
              />
              <br></br>
              <br></br>
            </label>
            <TextField
              id="outlined-multiline-static"
              label="Question"
              multiline
              rows={1}
              value={postRequest.question}
              onChange={handleQuestionChange}
              fullWidth
            />
            <br></br>
            <br></br>
            {postRequest.poll &&
              postRequest.poll.option.map((option) => (
                <Chip
                  style={{ marginBottom: "15px", marginRight: "5px" }}
                  key={option}
                  label={option}
                  onDelete={handleDeleteOption(option)}
                />
              ))}
            <br></br>
            <TextField
              value={optionInput}
              onChange={handleOptionInputChange}
              onKeyDown={handleOptionInputKeyDown}
              label="Option"
              fullWidth
            />

            <br></br>
            <br></br>

            <Button variant="contained" onClick={handleCreatePost} fullWidth>
              Create Post
            </Button>
          </Box>
        </Modal>

        <Modal
          style={{ marginTop: "100px", marginLeft: "500px" }}
          open={modal2Open}
          onClose={() => setModal2Open(false)}
          aria-labelledby="modal-modal-title"
          aria-describedby="modal-modal-description"
        >
          <Box sx={{ width: 400, padding: 2, bgcolor: "background.paper" }}>
            <Typography variant="caption">NEW GROUP</Typography>
            <br></br>
            <br></br>
            <TextField
              id="outlined-multiline-static"
              label="Name"
              multiline
              rows={2}
              value={groupRequest.name}
              onChange={handleNameChange}
              fullWidth
            />
            <br></br>
            <br></br>
            <TextField
              id="outlined-multiline-static"
              label="Description"
              multiline
              rows={4}
              value={groupRequest.description}
              onChange={handleDescriptionChange}
              fullWidth
            />
            <br></br>
            <label htmlFor="contained-button-file">
              <br></br>
              <Typography variant="caption">Upload Profile Image</Typography>
              <Input
                accept="image/*"
                id="contained-button-image"
                type="file"
                onChange={handleProfileImageChange}
              />
              <br></br>
              <br></br>
              <Typography variant="caption">Upload Cover Image</Typography>
              <Input
                accept="image/*"
                id="contained-button-image"
                type="file"
                onChange={handleCoverImageChange}
              />
              <br></br>
              <br></br>
            </label>
            <Button variant="contained" onClick={handleCreateGroup} fullWidth>
              Create Group
            </Button>
          </Box>
        </Modal>
      </div>
    </div>
  );
};

export default Navbar;
