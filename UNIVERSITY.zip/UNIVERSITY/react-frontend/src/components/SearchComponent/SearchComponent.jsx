import React, { useState } from 'react';
import axios from 'axios';
import { Link } from 'react-router-dom';
import UserService from '../../services/UserService';
import './SearchComponent.css';
import Avatar from "@mui/material/Avatar";

const SearchComponent = () => {
  const [searchTerm, setSearchTerm] = useState('');
  const [searchResults, setSearchResults] = useState({ groups: [], profiles: [] });
  const [searchCalled, setSearchCalled] = useState(false);

  const handleSearch = async () => {
    setSearchCalled(true);
    UserService.searchResultService(searchTerm).then((response) => {
      console.log("SearchResults");
      console.log(response.data);
      setSearchResults(response.data);
    }).catch((error) => {
      console.log(error);
    });
  };
  return (
    <div className="search-component">
      <input className="search-input" type="text" value={searchTerm} onChange={e => setSearchTerm(e.target.value)} />
      <button onClick={handleSearch}>Search</button>
      {searchCalled && <p>Profiles</p>}
      <div className="search-results">
        {searchResults.profiles.map(profile => (
          <Link to={`/profile/${profile.userId}`} key={profile.userId}>
            <div className="search-result-item" key={profile.userId}>
              <img src={`http://localhost:8080/api/v1/image/${profile.profilePicture}`} alt={profile.userName} />
              <div className="search-result-details">
                <div className="name">{profile.firstName}</div>
                <div className="username">@{profile.userName}</div>
              </div>
            </div>
          </Link>
        ))}
      </div>
      {searchCalled && <p>Groups</p>}
      <div className="search-results">
        {searchResults.groups.map(group => (
          <Link to={`/group/${group.groupId}`} key={group.userId}>
            <div className="search-result-item" key={group.groupId}>
              <Avatar src={`http://localhost:8080/api/v1/image/${group.profilePicture}`} alt={group.name} />
              <div className="search-result-details">
                <div className="name">{group.name}</div>
                <div className="username">@{group.groupId}</div>
              </div>
              <Link to={`/group/${group.groupId}`}>{group.name}</Link>
            </div>
          </Link>
        ))}
      </div>
    </div>
  );
};

export default SearchComponent;