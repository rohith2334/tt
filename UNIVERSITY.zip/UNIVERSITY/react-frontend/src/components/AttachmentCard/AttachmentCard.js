import "./AttachmentCard.css"
const AttachmentCard = ({ post }) => {
  // if (!post.attachments || post.attachments.length === 0) {
  //   return null;
  // }

  return (
    <div className="attachment-card">
      <p className="attachment-text">This post has attachments</p>
      <button className="attachment-button download-button">Download</button>
      <button className="attachment-button view-button">View</button>
    </div>
  );
};

export default AttachmentCard;