import "./post.css";
import FavoriteBorderOutlinedIcon from "@mui/icons-material/FavoriteBorderOutlined";
import FavoriteOutlinedIcon from "@mui/icons-material/FavoriteOutlined";
import TextsmsOutlinedIcon from "@mui/icons-material/TextsmsOutlined";
import { Link } from "react-router-dom";
import Comments from "../comments/Comments";
import { useEffect, useState } from "react";
import PostService from "../../services/PostService";
import Poll from "../post/Poll";
import IconButton from "@mui/material/IconButton";
import DeleteIcon from "@mui/icons-material/Delete";

import Icon from "@mui/material/Icon";
import PollIcon from "@mui/icons-material/Poll";
import { Typography } from "@mui/material";
import UserService from "../../services/UserService";

const Post = ({ post, setPosts }) => {
  const [commentOpen, setCommentOpen] = useState(false);
  const [liked, setLiked] = useState(post.liked);
  const [likesCount, setLikesCount] = useState(post.likes.length);
  const [commentsCount, setCommentsCount] = useState(post.comments.length);

  const handleLikeClick = () => {
    setLikesCount(liked ? likesCount - 1 : likesCount + 1);
    setLiked(!liked);
    PostService.likePost(post.id)
      .then(() => {
        setLiked((post.liked = !post.liked));
      })
      .catch((error) => {
        console.error("Failed to like post:", error);
      });
  };

  useEffect(() => {
    setLikesCount(post.likes.length);
  }, [post]);

  useEffect(() => {
    setCommentsCount(post.comments.length);
  }, [post]);
  const handleDelete = (id) => {
    UserService.deletePost(id)
      .then((response) => {
        console.log("Post deleted", response);
        setPosts((posts) => posts.filter((post) => post.id !== id));
      })
      .catch((error) => {
        console.error("Failed to delete post:", error);
      });
  };

  //TEMPORARY
  //  liked = false;
  let firstImage = post.images[0];
  console.log("First Image", firstImage);
  console.log(`http://localhost:8080/api/v1/image/${firstImage}`);

  return (
    <div className="post">
      <div className="container">
        <div className="user">
          <div className="userInfo">
            <img
              src={`http://localhost:8080/api/v1/image/${post.user.profilePic}`}
              alt=""
            />
            <div className="details">
              <Link
                to={`/profile/${post.user.id}`}
                style={{ textDecoration: "none", color: "inherit" }}
              >
                <span className="name">{post.user.userName}</span>
              </Link>
            </div>
            {/* <div className="details">
              <Link
                to={`/profile/${post.userId}`}
                style={{ textDecoration: "none", color: "green" }}
              >
                <span className="name">{post.user.userName}</span>
              </Link>
            </div> */}
          </div>
        {post.edit&& <IconButton aria-label="delete" onClick={() => handleDelete(post.id)}>
          <DeleteIcon />
        </IconButton>}
        </div>
        <div className="content">
          <p>{post.content}</p>
          <img
            src={`http://localhost:8080/api/v1/image/${firstImage}`}
            alt=""
          />
        </div>
        {post.poll && (
          <div>
            {/* <Icon style={{ marginLeft: "280px" }}>
              <PollIcon />
            </Icon> */}
            {/* <Typography
              style={{ marginLeft: "280px" }}
              variant="body2"
              component="div"
            >
              POLL
            </Typography> */}
            <Poll post={post.poll} postId={post.id} />
          </div>
        )}
        <div className="info">
          <div className="item" onClick={handleLikeClick}>
            {liked ? <FavoriteOutlinedIcon /> : <FavoriteBorderOutlinedIcon />}
            {likesCount} Likes
          </div>
          <div
            className="item"
            onClick={() => {
              if (post.comments.length >= 0) {
                setCommentOpen(!commentOpen);
              }
            }}
          >
            <TextsmsOutlinedIcon />
            {commentsCount} Comments
          </div>
        </div>
        {console.log("Post comments", post.comments)}
        {commentOpen && (
          <Comments
            comments={post.comments}
            postId={post.id}
            setCommentOpen={setCommentOpen}
            setCommentsCount={setCommentsCount}
            setPosts={setPosts}
          />
        )}
      </div>
    </div>
  );
};

export default Post;
