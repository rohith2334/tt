import React, { useState } from "react";
import Card from "@mui/material/Card";
import CardContent from "@mui/material/CardContent";
import Typography from "@mui/material/Typography";
import FormControl from "@mui/material/FormControl";
import FormControlLabel from "@mui/material/FormControlLabel";
import Radio from "@mui/material/Radio";
import RadioGroup from "@mui/material/RadioGroup";
import Box from "@mui/material/Box";
import "./poll.css";
import UserService from "../../services/UserService";

function Poll({ post, postId }) {
  const [selectedOption, setSelectedOption] = useState(null);

  const handleOptionChange = (event) => {
    setSelectedOption(event.target.value);
    console.log("Selected Option:", event.target.value);
    UserService.votePost(postId, event.target.value)
      .then((response) => {
        console.log("Vote response:", response);
        alert("Voted successfully");
        window.location.reload();
      })
      .catch((error) => {
        console.error("Failed to vote post:", error);
        alert("Failed to vote post");
      });
  };

  return (
    <Card className="poll-card">
      <CardContent>
        <Typography variant="h5" component="div">
          {post.question}
        </Typography>
        <FormControl component="fieldset" className="options">
          <RadioGroup value={selectedOption} onChange={handleOptionChange}>
            {Array.isArray(post.options) &&
              post.options.map((option, index) => (
                <FormControlLabel
                  key={index}
                  value={option.optionText}
                  control={
                    <Radio
                      checked={post.optionSelected === option.optionText}
                      disabled={post.optionSelected !== null}
                    />
                  }
                  label={option.optionText}
                  className="option"
                />
              ))}
          </RadioGroup>
        </FormControl>
        <Box display="flex" justifyContent="space-between" className="votes">
          <Typography variant="body2">
            Total votes: {post.totalVotes}
          </Typography>
          {Array.isArray(post.options) &&
            post.options.map((option, index) => (
              <Typography key={index} variant="body2" className="vote">
                {option.optionText}: {option.votes} votes
              </Typography>
            ))}
        </Box>
      </CardContent>
    </Card>
  );
}

export default Poll;
