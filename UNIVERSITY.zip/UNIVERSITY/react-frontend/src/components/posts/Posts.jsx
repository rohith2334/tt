import Post from "../post/Post";
import "./posts.css";
import React, { useEffect, useState } from "react";
import PostService from "../../services/PostService";

const Posts = ({ name }) => {
  const [posts, setPosts] = useState([]);

  useEffect(() => {
    if (name === "friends") {
      PostService.getPostsByUserIdForFriends()
        .then((response) => {
          setPosts(response.data);
          console.log(response.data);
        })
        .catch((error) => {
          console.error(error);
        });
    } else {
      PostService.getPostsById()
        .then((response) => {
          setPosts(response.data);
          console.log(response.data);
        })
        .catch((error) => {
          console.error(error);
        });
    }
  }, [name]);

  return (
    <div className="posts">
      {posts.map((post) => (
        <Post post={post} key={post.id} setPosts={setPosts} />
      ))}
    </div>
  );
};

export default Posts;
