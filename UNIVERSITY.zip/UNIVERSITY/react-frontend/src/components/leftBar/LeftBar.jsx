import "./leftBar.css";
import Friends from "../../assets/friends.png";
import Groups from "../../assets/group.png";
import Home from "../../assets/Home.png";
import Poll from "../../assets/poll.png";
import Saved from "../../assets/save.png";
import Search from "../../assets/search.png";

import Profile from "../../assets/profile.png";
import Logout from "../../assets/logout.png";

import { useNavigate } from "react-router-dom";

const LeftBar = () => {
  const navigate = useNavigate();
  const currentUser = localStorage.getItem("user")
    ? JSON.parse(localStorage.getItem("user"))
    : {};
  const userId = currentUser.id;

  const handleLogout = () => {
    localStorage.removeItem("authToken");
    localStorage.removeItem("user");
    navigate("/login");
  }

  return (
    <div className="leftBar">
      <div className="container">
        <div className="menu">
          <div className="item" onClick={() => navigate("/")}>
            <img src={Home} alt="" />
            <span>Home</span>
          </div>
          <div className="item" onClick={() => navigate("/groups")}>
            <img src={Groups} alt="" />
            <span>Groups</span>
          </div>
          <div className="item" onClick={() => navigate("/friends")}>
            <img src={Friends} alt="" />
            <span>Friends</span>
          </div>
          {/* <div className="item">
            <img src={Poll} alt="" />
            <span>My Polls</span>
          </div>
          <div className="item">
            <img src={Saved} alt="" />
            <span>Saved</span>
          </div> */}

          <div className="item" onClick={() => navigate(`/profile/${userId}`)}>
            <img src={Profile} alt="" />
            <span>Profile</span>
          </div>

          
          <div className="item" onClick={() => navigate(`/search`)}>
            <img src={Search} alt="" />
            <span>Search</span>
          </div>

          <div className="item" onClick={handleLogout}>
            <img src={Logout} alt="" />
            <span>Logout </span>
          </div>
        </div>
      </div>
    </div>
  );
};

export default LeftBar;
