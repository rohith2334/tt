import React, { useEffect, useState } from "react";
import "./Members.css";
import UserService from "../../services/UserService";

const Members = ({ view, groupId }) => {
  const [myFriends, setMyFriends] = useState([]);
  const currentUser = localStorage.getItem("user")
    ? JSON.parse(localStorage.getItem("user"))
    : {};
  const currentUserId = currentUser.id;
  useEffect(() => {
    console.log("View:::", view); 
    if (view === "profile") {
      UserService.getUserFriends()
        .then((response) => {
          setMyFriends(response.data);
        })
        .catch((error) => {
          console.log("Error", error);
        });
    } else {
      UserService.getGroupMembers(groupId)
        .then((response) => {
          setMyFriends(response.data);
        })
        .catch((error) => {
          console.log("Error", error);
        });
    }
  }, []);

  const handleUnfriend = (id) => {
    if (view === "profile") {
      UserService.unFriend(id)
        .then((response) => {
          console.log("Unfriended..!");
          alert("Unfriended");
          window.location.reload();
        })
        .then((error) => {
          console.log("ERROR:::", error);
        });
    } else {
      UserService.removeUserFromGroup(groupId)
        .then((response) => {
          console.log("User Removed from Group..!");
          alert("User Removed from Group");
          window.location.reload();
        })
        .then((error) => {
          console.log("ERROR:::", error);
        });
    }
  };

  const handleBan = (id) => {
    UserService.banUserFromGroup(groupId,id)
      .then((response) => {
        console.log("Unfriended..!");
      })
      .then((error) => {
        console.log("ERROR:::", error);
      });
  };

  return (
    <div className="members">
      <h2>{view==="profile"?"Friends":"Members"}</h2>
      {myFriends &&
        myFriends.map((user, index) => (
          <div key={index} className="member-card">
            {user.profilePicture && (
              <img
                src={`http://localhost:8080/api/v1/image/${user.profilePicture}`}
                alt="PRO"
              />
            )}
            <span className="username">{user && user.userName}</span>
            <div className="buttons">
              {currentUserId!==user.userId&&<button
                className="block-button"
                onClick={() => handleUnfriend(user.userId)}
              >
              {view === "profile" ? "Unfriend" : "Remove"}
              </button>}
             {view==="group"&&currentUserId!==user.userId&& <button
                className="remove-button"
                onClick={() => handleBan(user.userId)}
              >
                Ban
              </button>}
            </div>
          </div>
        ))}
    </div>
  );
};

export default Members;
