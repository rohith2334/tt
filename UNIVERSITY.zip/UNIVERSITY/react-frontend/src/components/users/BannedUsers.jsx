import React,{useEffect, useState} from 'react';
import './BannedUsers.css';
import UserService from '../../services/UserService';

const BannedUsers = ({view,groupId}) => {
  const [banned, setBanned] = useState([]);

  useEffect(() => {
    UserService.getGroupBannedUsers(groupId).then((response) => {
      setBanned(response.data);
    }).catch((error) => {
      console.log(error);
    });
  }, []);

  return (
    <div className="banned-users">
      <h2>Banned Users</h2>
      {banned &&banned.map((user, index) => (
        <div key={index} className="banned-user-card">
          <span className="username">{user.userName}</span>
        </div>
      ))}
    </div>
  );
};

export default BannedUsers;