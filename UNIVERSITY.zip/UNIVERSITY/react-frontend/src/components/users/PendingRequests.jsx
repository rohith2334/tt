import React, { useState, useEffect } from "react";
import "./PendingRequests.css";
import UserService from "../../services/UserService";

const PendingRequests = ({ view, groupId }) => {
  const [myFriendsRequests, setMyFriendsRequests] = useState([]);

  useEffect(() => {
    if (view === "profile") {
      UserService.getFriendRequests()
        .then((response) => {
          setMyFriendsRequests(response.data);
        })
        .catch((error) => {
          console.log("Error", error);
        });
    } else {
      UserService.getGroupFriendRequests(groupId)
        .then((response) => {
          setMyFriendsRequests(response.data);
        })
        .catch((error) => {
          console.log("Error", error);
        });
    }

  }, []);

  const handleAccept = (id) => {
    if (view === "profile") {
      UserService.respondToFriendRequest(id, "accept")
        .then((response) => {
          console.log("Accepted", response);
          alert("Friend Request Accepted");
          window.location.reload();
        })
        .catch((error) => {
          console.log("ERROR::::", error);
        });
      setMyFriendsRequests(myFriendsRequests.filter((user) => user.userId !== id));
    } else {
      UserService.respondToGroupFriendRequest(groupId, id, "accept")
        .then((response) => {
          console.log("Accepted", response);
          alert("Friend Request Accepted");
          window.location.reload();
        })
        .catch((error) => {
          console.log("ERROR::::", error);
        });
      setMyFriendsRequests(myFriendsRequests.filter((user) => user.userId !== id));
    }

  };

  const handleReject = (id) => {
    if (view === "profile") {
      UserService.respondToFriendRequest(id, "reject")
        .then((response) => {
          console.log("REJECTED", response);
          alert("Friend Request Rejected");
          window.location.reload();
        })
        .catch((error) => {
          console.log("ERROR::::", error);
        });

    } else {
      UserService.respondToGroupFriendRequest(groupId, id, "reject")
        .then((response) => {
          console.log("REJECTED", response);
          alert("Friend Request Rejected");
          window.location.reload();
        })
        .catch((error) => {
          console.log("ERROR::::", error);
        });
    }
  };

  return (
    <div className="pending-requests">
      <h2>Pending Requests</h2>
      {myFriendsRequests &&
        myFriendsRequests.map((user, index) => (
          <div key={index} className="request-card">
            <span className="username">{user.userName}</span>
            <div className="buttons">
              <button
                className="accept-button"
                onClick={() => handleAccept(user.userId)}
              >
                Accept
              </button>
              <button className="reject-button"
                onClick={() => handleReject(user.userId)}
              >Reject</button>
            </div>
          </div>
        ))}
    </div>
  );
};

export default PendingRequests;
