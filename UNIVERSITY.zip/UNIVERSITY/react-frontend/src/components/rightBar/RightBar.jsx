import UserRequestCard from "../userRequestCard/UserRequestCard";
import "./rightBar.css";
import { useEffect, useState } from "react";
import UserService from "../../services/UserService";
import UserSuggestionCard from "../userRequestCard/UserSuggestionCard";

const RightBar = () => {
  const [friendRequest, setFriendRequest] = useState([]);
  const [followSuggestions, setFollowSuggestions] = useState([]);
  const handleFollow = (userId) => {
    setFollowSuggestions(
      followSuggestions.filter((user) => user.userId !== userId)
    );
  };
  const handleAcceptOrReject = (userId) => {
    setFriendRequest(friendRequest.filter((user) => user.userId !== userId));
  };

  useEffect(() => {
    UserService.getFriendRequests()
      .then((response) => {
        setFriendRequest(response.data);
        console.log("FR", response.data);
      })
      .catch((error) => {
        console.log(error);
      });

    UserService.getFollowSuggestions()
      .then((response) => {
        setFollowSuggestions(response.data);
        console.log("FS", response.data);
      })
      .catch((error) => {
        console.log(error);
      });
  }, []);
  return (
    <div className="rightBar">
      <div className="container">
        <div className="item">
          <span>Friend Requests</span>
          {friendRequest &&
            friendRequest.map((user) => (
              <UserRequestCard
                key={user._id}
                profile={user}
                onAcceptOrReject={() => handleAcceptOrReject(user.userId)}
              />
            ))}
        </div>
        <div className="item">
          <span>Follow Suggestions</span>
          {followSuggestions &&
            followSuggestions.map((user) => (
              <UserSuggestionCard
                key={user._id}
                profile={user}
                onFollow={() => handleFollow(user.userId)}
              />
            ))}
        </div>
      </div>
    </div>
  );
};

export default RightBar;
