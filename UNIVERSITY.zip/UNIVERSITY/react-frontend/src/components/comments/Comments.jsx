import { useEffect } from "react";
import "./comment.css";
import UserService from "../../services/UserService";
import { useState } from "react";
import PostService from "../../services/PostService";


function timeSince(date) {
  var seconds = Math.floor((new Date() - date) / 1000);

  var interval = seconds / 31536000;

  if (interval > 1) {
    return Math.floor(interval) + " years";
  }
  interval = seconds / 2592000;
  if (interval > 1) {
    return Math.floor(interval) + " months";
  }
  interval = seconds / 86400;
  if (interval > 1) {
    return Math.floor(interval) + " days";
  }
  interval = seconds / 3600;
  if (interval > 1) {
    return Math.floor(interval) + " hours";
  }
  interval = seconds / 60;
  if (interval > 1) {
    return Math.floor(interval) + " minutes";
  }
  return Math.floor(seconds) + " seconds";
}

const Comments = ({
  comments,
  postId,
  setCommentOpen,
  setCommentsCount,
  setPosts,
}) => {
  const currentUser = localStorage.getItem("user")
    ? JSON.parse(localStorage.getItem("user"))
    : {};
  const userId = currentUser.id;
  console.log("Comments of post", comments);
  const [userDetails, setUserDetails] = useState({});
  const [localCount, setLocalCount] = useState(0);
  const [commentRequest, setCommentRequest] = useState({
    message: "",
  });

  useEffect(() => {
    UserService.getUserById(userId)
      .then((response) => {
        setUserDetails(response.data);
      })
      .catch((error) => {
        console.error("Failed to get user details:", error);
      });
  }, []);

  useEffect(() => {
    PostService.getPostsById()
      .then((response) => {
        console.log("RESPONSE FOR COMMENTS", response.data[0].comments);
        setPosts([...response.data]);
      })
      .catch((error) => {
        console.error("Failed to get real time comments:", error);
      });
  }, [localCount]);

  const handleText = (e) => {
    setCommentRequest({ ...commentRequest, message: e.target.value });
  };

  const handleSendComment = () => {
    window.location.reload();
    setCommentOpen(false);
    setCommentsCount(comments.length + 1);
    setLocalCount(localCount + 1);
    console.log("Comment Request", commentRequest);
    UserService.sendComment(postId, commentRequest)
      .then((response) => {
        console.log("Comment Response", response.data);
      })
      .catch((error) => {
        console.error("Failed to send comment:", error);
      });
  };
  return (
    <div className="comments">
      <div className="write">
        <img
          src={`http://localhost:8080/api/v1/image/${userDetails.profilePicture}`}
          alt=""
        />
        <input
          type="text"
          onChange={handleText}
          placeholder="write a comment"
        />
        <button onClick={handleSendComment}>Send</button>
      </div>
      {console.log("REALK", comments)}
      {comments &&
        comments.map((comment) => (
          <div className="comment" key={comment.id}>
            {comment.profilePic && (
              <img
                src={`http://localhost:8080/api/v1/image/${comment.profilePic}`}
                alt="PRO"
              />
            )}
            <div className="info">
              <span>
                <b>{comment.username && comment.username}</b>
              </span>
              <p>{comment.message && comment && comment.message}</p>
              <span>{timeSince(new Date(comment.createdAt))} ago</span>{" "}
            </div>
          </div>
        ))}
    </div>
  );
};

export default Comments;
