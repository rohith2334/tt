import httpClient from './http-common';


const getPostsById=()=>{
    return httpClient.get(`/post/user`);
}

const getPostsByUserIdForFriends=()=>{
    const friends=true
    return httpClient.get(`/post/user?friends=${friends}`);

}

const likePost=(postId)=>{
    return httpClient.patch(`/post/${postId}/like`);
}

// eslint-disable-next-line import/no-anonymous-default-export
export default {getPostsById,likePost,getPostsByUserIdForFriends};  