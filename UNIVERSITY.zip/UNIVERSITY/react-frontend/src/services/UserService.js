import httpClient from "./http-common";

const userLogin = (data) => {
  console.log(data);
  return httpClient.post("/auth/signin", data);
};

const userSignup = (data) => {
  console.log(data);
  return httpClient.post("/auth/signup", data);
};

const getUsers = () => {
  return httpClient.get("/user/all");
};

const getAllGroups = () => {
  return httpClient.get("/group/all");
};

const getFriendRequests = () => {
  return httpClient.get("/user/friendRequests");
};

const getFollowSuggestions = () => {
  return httpClient.get("/user/friendSuggestion");
};

const respondToFriendRequest = (userId, status) => {
  return httpClient.patch(`/user/respondFriendRequest/${userId}/${status}`);
};

const sendFriendRequest = (userId) => {
  console.log("SEND:::", userId);
  return httpClient.patch(`/user/sendFriendRequest/${userId}`);
};

const getGroups = () => {
  return httpClient.get(`/group/myGroups`);
};

const getUserById = (userId) => {
  return httpClient.get(`/user/${userId}`);
};

const uploadFile = (data) => {
  console.log("form req", data.get("file"));
  return httpClient.post(`/file/upload`, data);
};

const createPost = (data) => {
  return httpClient.post(`/post/`, data);
};

const uploadImage = (data) => {
  let request = { image: data };
  return httpClient.post(`/image/upload`, request);
};

const createGroup = (data) => {
  return httpClient.post(`/group/`, data);
};

const getGroupDetails = (groupId) => {
  return httpClient.get(`/group/${groupId}`);
};

const getNonVerifiedUsers = () => {
  return httpClient.get(`/user/getNonApprovedUsers`);
};

const getNonVerifiedGroups = () => {
  return httpClient.get(`/group/getNonApprovedGroups`);
};

const getPosts = () => {
  return httpClient.get("/post/all");
};

const verifyUser = (userId) => {
  return httpClient.patch(`/user/${userId}/approve`);
};

const verifyGroup = (groupId) => {
  return httpClient.patch(`/group/${groupId}/approve`);
};

const sendComment = (postId, data) => {
  return httpClient.post(`post/${postId}/comment`, data);
};

const getUserFriends = () => {
  return httpClient.get(`user/friends`);
};

const blockFriend = (id) => {
  return httpClient.patch(`/user/block/${id}`);
};

const unFriend = (id) => {
  return httpClient.patch(`/user/unFriend/${id}`);
};

const votePost = (postId, option) => {
  return httpClient.patch(`/post/${postId}/poll?option=${option}`);
};

const deletePost = (postId) => {
  return httpClient.delete(`/post/${postId}`);
};

const getNotifications = () => {
  return httpClient.get(`/notifications/`);
};

const updateNotification = (notificationId) => {
  return httpClient.patch(`/notifications/${notificationId}`);
};

const searchResultService = (notificationId) => {
  return httpClient.get(`/search?term=${notificationId}`);
};

const deleteFriendRequest = (userId) => {
  return httpClient.delete(`/user/deleteFriendRequest/${userId}`);
};

const sendRequestToGroup = (groupId) => {
  return httpClient.patch(`/group/sendRequest/${groupId}`);
};

const cancelRequestToGroup = (groupId) => {
  return httpClient.patch(`/group/cancelRequest/${groupId}`);
};

const unFollowGroup = (groupId) => {
  return httpClient.patch(`/group/unfollow/${groupId}`);
};

const getGroupFriendRequests = (groupId) => {
  return httpClient.get(`/group/${groupId}/requests`);
};

const getGroupMembers = (groupId) => {
  return httpClient.get(`/group/${groupId}/members`);
};

const getGroupBannedUsers = (groupId) => {
  return httpClient.get(`/group/${groupId}/bannedMembers`);
};

const respondToGroupFriendRequest = (groupId, userId, status) => {
  return httpClient.patch(`/group/${groupId}/${userId}/${status}`);
};

const banUserFromGroup = (groupId, userId) => {
  return httpClient.patch(`/group/${groupId}/${userId}/ban`);
};

const removeUserFromGroup = (groupId, userId) => {
  return httpClient.patch(`/group/removeUserFromGroup/${groupId}/${userId}`);
};

// eslint-disable-next-line import/no-anonymous-default-export
export default {
  userLogin,
  userSignup,
  getFriendRequests,
  getFollowSuggestions,
  respondToFriendRequest,
  sendFriendRequest,
  getUserById,
  getGroups,
  uploadFile,
  createPost,
  uploadImage,
  createGroup,
  getGroupDetails,
  getUsers,
  getAllGroups,
  getNonVerifiedUsers,
  getNonVerifiedGroups,
  getPosts,
  verifyUser,
  verifyGroup,
  sendComment,
  getUserFriends,
  unFriend,
  blockFriend,
  votePost,
  deletePost,
  getNotifications,
  updateNotification,
  searchResultService,
  deleteFriendRequest,
  sendRequestToGroup,
  cancelRequestToGroup,
  unFollowGroup,
  getGroupFriendRequests,
  getGroupMembers,
  getGroupBannedUsers,
  respondToGroupFriendRequest,
  banUserFromGroup,
  removeUserFromGroup,
};
