import { useContext } from "react";
import { createBrowserRouter, RouterProvider, Outlet, Navigate } from "react-router-dom";
import Navbar from "./components/navbar/Navbar";
import LeftBar from "./components/leftBar/LeftBar";
import RightBar from "./components/rightBar/RightBar";
import Home from "./pages/home/Home";
import Group from "./pages/group/Group";
import Profile from "./pages/profile/Profile";
import Login from "./pages/login/Login";
import Register from "./pages/register/Register";
// import Register from "./pages/register/Register";
import { AuthContext } from "./context/authContext";
import { DarkModeContext } from "./context/darkModeContext";
import "./style.css";
import ViewGroups from "./pages/group/ViewGroups";
import AdminPage from "./components/AdminPage";
import Search from "./components/SearchComponent/SearchComponent";

function App() {
  const { currentUser } = useContext(AuthContext);
  const { darkMode } = useContext(DarkModeContext);

  const Layout = () => (
    <div className={`theme-${darkMode ? "dark" : "light"}`}>
      <Navbar />
      <div style={{ display: "flex" }}>
        <LeftBar />
        <div style={{ flex: 6 }}>
          <Outlet />
        </div>
        <RightBar />
      </div>
    </div>
  );

  const ProtectedRoute = ({ children }) => (!currentUser ? <Navigate to="/login" /> : children);

  const router = createBrowserRouter([
    {
      path: "/",
      element: <ProtectedRoute><Layout /></ProtectedRoute>,
      children: [
        { path: "/", element: <Home /> },
        { path: "/profile/:id", element: <Profile /> },
        { path: "/group/:id", element: <Group /> },
        { path: "/groups", element: <ViewGroups /> },
        { path: "/search", element: <Search /> },
        { path: "/friends", element: <Home view={"friends"}/> }
      ],
    },
    {
      path: "/login",
      element: <Login />,
    },
    {
      path: "/register",
      element: <Register />,
    },

    {
      path: "/admin",
      element: <AdminPage />,
    },
  ]);

  return <RouterProvider router={router} />;
}

export default App;