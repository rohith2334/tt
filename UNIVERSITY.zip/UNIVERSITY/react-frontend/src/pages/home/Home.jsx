import Posts from "../../components/posts/Posts";
import Share from "../../components/share/Share";
import "./home.css";

const Home = ({view}) => {
  return (
    <div className="home">
      {/* <Stories/> */}
      {/*<Share />*/}
      <Posts name={view}/>
    </div>
  );
};

export default Home;
