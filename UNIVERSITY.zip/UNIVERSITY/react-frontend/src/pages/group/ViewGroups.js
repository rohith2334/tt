import React, { useEffect, useState } from 'react';
import UserService from '../../services/UserService';
import Avatar from '@mui/material/Avatar';
import Card from '@mui/material/Card';
import CardContent from '@mui/material/CardContent';
import Typography from '@mui/material/Typography';
import { Button } from '@mui/material';
import { useNavigate } from 'react-router-dom';

function ViewGroups() {
  const [groups, setGroups] = useState([]);
  const navigate = useNavigate();

  useEffect(() => {
    UserService.getGroups()
      .then(response => {
        setGroups(response.data);
      })
      .catch(error => {
        console.error('There was an error!', error);
      });
  }, []);

  const handleViewClick = (groupId) => {
    navigate(`/group/${groupId}`);
  };

  return (
    <div>
      {groups && groups.map((group, index) => (
        <Card key={index} sx={{ maxWidth: 400, marginBottom: 2, marginLeft:20, marginTop:10 }}>
          <CardContent>
            <Avatar alt={group.name} src={`http://localhost:8080/api/v1/image/${group.profileImage}`} />
            <Typography variant="h6" component="div">
              {group.name}
            </Typography>
            <Typography variant="body2">
              Members: {group.memberCount}
            </Typography>
            <Button onClick={()=>handleViewClick(group.groupId)}>
                VIEW
            </Button>
          </CardContent>
        </Card>
      ))}
    </div>
  );
}

export default ViewGroups;