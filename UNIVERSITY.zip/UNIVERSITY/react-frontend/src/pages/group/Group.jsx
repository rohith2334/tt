import "./group.css";
import FacebookTwoToneIcon from "@mui/icons-material/FacebookTwoTone";
import LinkedInIcon from "@mui/icons-material/LinkedIn";
import InstagramIcon from "@mui/icons-material/Instagram";
import PinterestIcon from "@mui/icons-material/Pinterest";
import TwitterIcon from "@mui/icons-material/Twitter";
import PlaceIcon from "@mui/icons-material/Place";
import LanguageIcon from "@mui/icons-material/Language";
import EmailOutlinedIcon from "@mui/icons-material/EmailOutlined";
import MoreVertIcon from "@mui/icons-material/MoreVert";
import Posts from "../../components/posts/Posts"
import CheckCircleIcon from '@mui/icons-material/CheckCircle';
import React, { useEffect, useState } from 'react';
import { useParams } from 'react-router-dom';
import UserService from '../../services/UserService';

import PendingRequests from "../../components/users/PendingRequests";
import Members from "../../components/users/Members";
import BannedUsers from "../../components/users/BannedUsers";


const Group = () => {
  const [activeTab, setActiveTab] = useState('posts');
  const { id } = useParams();
  const [group, setGroup] = useState({});

  useEffect(() => {
    console.log('activeTab:', activeTab);
    UserService.getGroupDetails(id).then((response) => {
      setGroup(response.data);
      console.log(response.data);
    }).catch((error) => {
      console.log(error);
    });
  }, [activeTab]);

  return (
    <div className="profile">
      <div className="images">
        <img
          src={`http://localhost:8080/api/v1/image/${group.coverImage}`}
          alt=""
          className="cover"
        />
        <img
          src={`http://localhost:8080/api/v1/image/${group.profileImage}`}
          alt=""
          className="profilePic"
        />
      </div>
      <div className="profileContainer">
        <div className="uInfo">
          <div className="left">
            <a href="http://facebook.com">
              <FacebookTwoToneIcon fontSize="large" />
            </a>
            <a href="http://facebook.com">
              <InstagramIcon fontSize="large" />
            </a>
          </div>
          <div className="center">
            <span>{group.name}</span>
            {/* <div className="info">
              <div className="item">
                {group.userName}
              </div>
            </div> */}
            {
              !group.edit && (
                console.log('group.groupStatus:', group.groupStatus),
                <button
                  onClick={() => {
                    if (group.groupStatus === 'none') {
                      UserService.sendRequestToGroup(group.groupId).then((response) => {
                        console.log(response.data);
                        window.location.reload();
                      }).catch((error) => {
                        console.log(error);
                      });
                      console.log('follow group');
                    } else if (group.groupStatus === 'member') {
                      UserService.unfollowGroup(group.groupId).then((response) => {
                        console.log(response.data);
                        window.location.reload();
                      }).catch((error) => {
                        console.log(error);
                        alert("ERROR::Unfollow group ",error);
                      });
                    } else if (group.groupStatus === 'pending') {
                      UserService.cancelRequestToGroup(group.groupId).then((response) => {
                        console.log(response.data);
                        window.location.reload();
                      }).catch((error) => {});
                    } 
                  }}
                  disabled={group.groupStatus === 'blocked'}
                >
                  {group.groupStatus === 'none' && 'Follow'}
                  {group.groupStatus === 'member' && 'Unfollow'}
                  {group.groupStatus === 'banned' && 'Banned'}
                  {group.groupStatus === 'pending' && 'Cancel Request'}
                </button>
              )
            }
          </div>
          <div className="right">
            {group.verified && <CheckCircleIcon color="primary" sx={{ color: '#0a66c2' }} />}
          </div>
        </div>
        <div className="tabBar">
          <button onClick={() => setActiveTab('posts')}>Posts</button>
          {group.edit && <button onClick={() => setActiveTab("manage")}>Manage</button>}
        </div>
        {activeTab === 'posts' && <Posts />}
        {activeTab === 'manage' && (
          <div className="tabBar">
            <button onClick={() => setActiveTab('pendingRequests')}>Pending Requests</button>
            <button onClick={() => setActiveTab('members')}>Members</button>
            <button onClick={() => setActiveTab('bannedUsers')}>Banned Users</button>
          </div>
        )}
        {activeTab === 'pendingRequests' && <PendingRequests view={"group"} groupId ={group.groupId} />}
        {activeTab === 'members' && <Members view={"group"} groupId={group.groupId}/>}
        {activeTab === 'bannedUsers' && <BannedUsers view={"group"} groupId={group.groupId} />}
      </div>
    </div>
  );
};

export default Group;