import { Link } from "react-router-dom";
import { useState } from "react";
import "./login.css";
import UserService from "../../services/UserService";

const Login = () => {
  const [currentUser, setCurrentUser] = useState({ email: "", password: "" });
  const handleChange = ({ target }) => {
    setCurrentUser({ ...currentUser, [target.name]: target.value });
  };
  const handleSubmit = (e) => {
    e.preventDefault();
    UserService.userLogin(currentUser).then((response) => {
      localStorage.removeItem("user");
      localStorage.removeItem("userDetails");
      console.log(response.data);
      localStorage.setItem("user", JSON.stringify(response.data));
      const jwtToken = response.headers["x-jwt-token"];
      console.log("jwtToken::::::", jwtToken);
      localStorage.setItem("jwtToken", jwtToken);
      if(response.data.role === "ROLE_ADMIN") {
        window.location = "/admin";
      }else{
        window.location.replace("/");
      }
     
    });
  };
  return (
    <div className="login">
      <div className="card">
        <div className="left">
          <h3>UNIVERSITY BLOG APP</h3>
          <span>Don't you have an account?</span>
          <Link to="/register">
            <button>Register</button>
          </Link>
        </div>
        <div className="right">
          <h1>Login</h1>
          <form>
            <input
              type="text"
              placeholder="email"
              name="email"
              onChange={handleChange}
              value={currentUser.email}
              required
            />
            <input
              type="password"
              placeholder="Password"
              name="password"
              onChange={handleChange}
              value={currentUser.password}
              required
            />
            <button type="submit" onClick={handleSubmit}>
              Login
            </button>
          </form>
        </div>
      </div>
    </div>
  );
};

export default Login;
