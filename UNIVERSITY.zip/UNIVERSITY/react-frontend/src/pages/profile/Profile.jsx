import "./profile.css";
import FacebookTwoToneIcon from "@mui/icons-material/FacebookTwoTone";
import InstagramIcon from "@mui/icons-material/Instagram";
import Posts from "../../components/posts/Posts";
import React, { useEffect, useState } from "react";
import { useParams } from "react-router-dom";
import CheckCircleIcon from '@mui/icons-material/CheckCircle';
import { useMatch } from 'react-router-dom';
import PendingRequests from "../../components/users/PendingRequests";
import Members from "../../components/users/Members";
import UserService from "../../services/UserService";

const Profile = () => {
  
  const [activeTab, setActiveTab] = useState("posts");
  const [profile, setProfile] = useState({});
  const currentUser = localStorage.getItem("user")
    ? JSON.parse(localStorage.getItem("user"))
    : {};
  const currentUserId = currentUser.id;
  const { id } = useParams();
  const match = useMatch(`/group/${id}`);

  
  useEffect(() => {
    if (match) {
      console.log('Group path detected::::::::::::::::::::::::::::');
      // Do something if the path includes '/group/:id'

    } else {
      console.log('Group path not detected');
      // Do something else if the path does not include '/group/:id'
    }
  }, []);


  const addFriend = () => {
    console.log("Add friend function called");
    UserService.sendFriendRequest(id).then((response) => {
      console.log(response.data);
      alert("Friend request sent successfully");
      window.location.reload();
    }).catch((error) => {
      console.log(error);
    alert("ERROR::Friend request ",error);
    })
  }
  
  const unfriend = () => {
    console.log("Unfriend function called");
    UserService.unFriend(id).then((response) => {
      console.log(response.data);
      alert("Unfriended successfully");
      window.location.reload();
    }).catch((error) => {
      console.log(error);
      alert("ERROR::Unfriend ",error);
    });
    // Call your API or function to unfriend here
  }
  
  const cancelRequest = () => {
    console.log("Cancel request function called");
    UserService.deleteFriendRequest(id).then((response) => {
      console.log(response.data);
      alert("Request cancelled successfully");
      window.location.reload();

    }).catch((error) => {
      console.log(error);
      alert("ERROR::Cancel request ",error);
    });
   }

  useEffect(() => {
    UserService.getUserById(id).then((response) => {
      setProfile(response.data);
      console.log(response.data);
    }).catch((error) => {
      console.log(error);
    });
  }, [activeTab, id]);

  return (
    <div className="profile">
      <div className="images">
        <img
          src="https://images.unsplash.com/20/cambridge.JPG?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3wxMjA3fDB8MXxzZWFyY2h8MTV8fHVuaXZlcnNpdGllc3xlbnwwfHx8fDE3MTMxODkyODZ8MA&ixlib=rb-4.0.3&q=80&w=1080"
          alt=""
          className="cover"
        />
        <img
          src={`http://localhost:8080/api/v1/image/${profile.profilePicture}`}
          alt=""
          className="profilePic"
        />
      </div>
      <div className="profileContainer">
        <div className="uInfo">
          <div className="left">
            <a href="http://facebook.com">
              <FacebookTwoToneIcon fontSize="large" />
            </a>
            <a href="http://facebook.com">
              <InstagramIcon fontSize="large" />
            </a>
          </div>
          <div className="center">
            <span>{profile.firstName + " " + profile.lastName}</span>
            <div className="info">
              <div className="item">
                {profile.userName}
              </div>
            </div>
            {
              !profile.edit && (
                <button
                  onClick={() => {
                    if (profile.friendStatus === 'none') {
                      addFriend();
                    } else if (profile.friendStatus === 'friends') {
                      unfriend();
                    } else if (profile.friendStatus === 'pending') {
                      cancelRequest();
                    }
                  }}
                  disabled={profile.friendStatus === 'blocked'}
                >
                  {profile.friendStatus === 'none' && 'Add Friend'}
                  {profile.friendStatus === 'friends' && 'Unfriend'}
                  {profile.friendStatus === 'blocked' && 'Blocked'}
                  {profile.friendStatus === 'pending' && 'Cancel Request'}
                </button>
              )
            }
          </div>
          <div className="right">
            {profile.verified && <CheckCircleIcon color="primary" sx={{ color: '#0a66c2' }} />}
          </div>
        </div>
        <div className="tabBar">
          <button onClick={() => setActiveTab("posts")}>Posts</button>
          {profile.edit && <button onClick={() => setActiveTab("manage")}>Manage</button>}
        </div>
        {activeTab === "posts" && <Posts />}
        {(activeTab === "manage") && (
          <div className="tabBar">
            <button onClick={() => setActiveTab("members")}>Friends</button>

            <button onClick={() => setActiveTab("pendingRequests")}>
              Pending Requests
            </button>
          </div>
        )}
        {activeTab === "pendingRequests" && <PendingRequests view={"profile"} />}
        {activeTab === "members" && <Members view={"profile"} />}
      </div>
    </div>
  );
};

export default Profile;
