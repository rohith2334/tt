import { Link, useNavigate } from "react-router-dom";
import { useState } from "react";
import "./register.css";
import UserService from "../../services/UserService";
import React, { useEffect } from "react";

const Register = () => {
  const [username, setUsername] = useState("");
  const [password, setPassword] = useState("");
  const [confirmPassword, setConfirmPassword] = useState("");

  const [registerRequest, setRegisterRequest] = useState({
    firstName: "",
    lastName: "",
    email: "",
    username: "",
    password: "",
    profileImage: "",
    phoneNumber: "",
  });

  useEffect(() => {
    console.log("Register component is mounted");
    console.log("Username: ", username);
    console.log("Password:");
    setUsername("");
    setPassword("");
  }, []);

  const navigate = useNavigate();

  const handleSubmit = async (e) => {
    console.log(registerRequest);
    e.preventDefault();
    if (registerRequest.password !== confirmPassword) {
      // Prevent form submission and show an error message
      alert("Passwords do not match");
      return;
    }
    UserService.userSignup(registerRequest)
      .then((response) => {
        alert("Account created successfully"); // Show a popup
        navigate("/login"); // Navigate to "/signin"
      })
      .catch((error) => {
        console.log(error);
      });
  };

  const handleImageChange = (event) => {
    if (event.target.files.length > 0) {
      let reader = new FileReader();
      reader.onloadend = () => {
        setRegisterRequest({ ...registerRequest, profileImage: reader.result });
      };
      reader.readAsDataURL(event.target.files[0]);
    }
  };

  const handleInputChange = (event) => {
    setRegisterRequest({
      ...registerRequest,
      [event.target.name]: event.target.value,
    });
  };
  return (
    <div className="register">
      <div className="card">
        <div className="right">
          <h1>Register</h1>
          <form>
            <input
              type="text"
              name="firstName"
              placeholder="First Name"
              onChange={handleInputChange}
            />
            <input
              type="text"
              name="lastName"
              placeholder="Last Name"
              onChange={handleInputChange}
            />
            <input
              type="email"
              name="email"
              placeholder="Email"
              onChange={handleInputChange}
            />
            <input
              type="text"
              name="username"
              placeholder="Username"
              onChange={handleInputChange}
            />
            <input
              type="password"
              name="password"
              placeholder="Password"
              onChange={handleInputChange}
            />
            <input
              type="password"
              name="confirmPassword"
              placeholder="Confirm Password"
              onChange={(e) => setConfirmPassword(e.target.value)}
            />
            <input
              type="text"
              name="phoneNumber"
              placeholder="Phone Number"
              onChange={handleInputChange}
            />
            <input
              type="file"
              name="profileImage"
              accept="image/jpeg, image/jpg, image/png"
              onChange={handleImageChange}
              label="Profile Picture"
            />
            <button onClick={handleSubmit}>Register </button>
          </form>
          <span>Do you have an account?</span>
          <Link to="/login">
            <button>Login</button>
          </Link>
        </div>
      </div>
    </div>
  );
};

export default Register;
